using System;
using System.Runtime.InteropServices;
using System.Text;

namespace Zenith.iOS.GL
{
    /// <summary>
    /// Minimal OpenGL ES 3.0 binding (direct P/Invoke into Apple's OpenGLES.framework).
    /// Only the calls Zenith needs.  Everything is ES-legal: no client state, no quads,
    /// no double-precision vertex data.
    /// </summary>
    internal static unsafe class Gl
    {
        const string Lib = "/System/Library/Frameworks/OpenGLES.framework/OpenGLES";

        // ---- constants -------------------------------------------------------------
        public const int BLEND = 0x0BE2, DEPTH_TEST = 0x0B71;
        public const int ZERO = 0, ONE = 1, SRC_ALPHA = 0x0302, ONE_MINUS_SRC_ALPHA = 0x0303;
        public const int LESS = 0x0201, ALWAYS = 0x0207;
        public const int COLOR_BUFFER_BIT = 0x4000, DEPTH_BUFFER_BIT = 0x0100;
        public const int FRAMEBUFFER = 0x8D40, RENDERBUFFER = 0x8D41;
        public const int COLOR_ATTACHMENT0 = 0x8CE0, DEPTH_ATTACHMENT = 0x8D00;
        public const int FRAMEBUFFER_COMPLETE = 0x8CD5;
        public const int DEPTH_COMPONENT24 = 0x81A6;
        public const int TEXTURE_2D = 0x0DE1, TEXTURE0 = 0x84C0;
        public const int RGBA = 0x1908, RGBA8 = 0x8058;
        public const int UNSIGNED_BYTE = 0x1401, UNSIGNED_INT = 0x1405, FLOAT = 0x1406;
        public const int TEXTURE_MAG_FILTER = 0x2800, TEXTURE_MIN_FILTER = 0x2801;
        public const int TEXTURE_WRAP_S = 0x2802, TEXTURE_WRAP_T = 0x2803;
        public const int NEAREST = 0x2600, LINEAR = 0x2601, CLAMP_TO_EDGE = 0x812F;
        public const int ARRAY_BUFFER = 0x8892, ELEMENT_ARRAY_BUFFER = 0x8893;
        public const int STREAM_DRAW = 0x88E0, STATIC_DRAW = 0x88E4, DYNAMIC_DRAW = 0x88E8;
        public const int TRIANGLES = 0x0004, TRIANGLE_FAN = 0x0006;
        public const int VERTEX_SHADER = 0x8B31, FRAGMENT_SHADER = 0x8B30;
        public const int COMPILE_STATUS = 0x8B81, LINK_STATUS = 0x8B82, INFO_LOG_LENGTH = 0x8B84;
        public const int PACK_ALIGNMENT = 0x0D05, UNPACK_ALIGNMENT = 0x0CF5;
        public const int NO_ERROR = 0;

        // ---- state -----------------------------------------------------------------
        [DllImport(Lib)] public static extern void glEnable(int cap);
        [DllImport(Lib)] public static extern void glDisable(int cap);
        [DllImport(Lib)] public static extern void glBlendFunc(int sfactor, int dfactor);
        [DllImport(Lib)] public static extern void glDepthFunc(int func);
        [DllImport(Lib)] public static extern void glViewport(int x, int y, int width, int height);
        [DllImport(Lib)] public static extern void glClear(int mask);
        [DllImport(Lib)] public static extern void glClearColor(float r, float g, float b, float a);
        [DllImport(Lib)] public static extern void glFinish();
        [DllImport(Lib)] public static extern void glFlush();
        [DllImport(Lib)] public static extern int glGetError();
        [DllImport(Lib)] public static extern void glPixelStorei(int pname, int param);

        // ---- objects ---------------------------------------------------------------
        [DllImport(Lib)] public static extern void glGenBuffers(int n, int* buffers);
        [DllImport(Lib)] public static extern void glDeleteBuffers(int n, int* buffers);
        [DllImport(Lib)] public static extern void glBindBuffer(int target, int buffer);
        [DllImport(Lib)] public static extern void glBufferData(int target, nint size, void* data, int usage);

        [DllImport(Lib)] public static extern void glGenTextures(int n, int* textures);
        [DllImport(Lib)] public static extern void glDeleteTextures(int n, int* textures);
        [DllImport(Lib)] public static extern void glBindTexture(int target, int texture);
        [DllImport(Lib)] public static extern void glActiveTexture(int texture);
        [DllImport(Lib)] public static extern void glTexParameteri(int target, int pname, int param);
        [DllImport(Lib)] public static extern void glTexImage2D(int target, int level, int internalformat, int width, int height, int border, int format, int type, void* pixels);

        [DllImport(Lib)] public static extern void glGenFramebuffers(int n, int* framebuffers);
        [DllImport(Lib)] public static extern void glDeleteFramebuffers(int n, int* framebuffers);
        [DllImport(Lib)] public static extern void glBindFramebuffer(int target, int framebuffer);
        [DllImport(Lib)] public static extern void glFramebufferTexture2D(int target, int attachment, int textarget, int texture, int level);
        [DllImport(Lib)] public static extern void glFramebufferRenderbuffer(int target, int attachment, int renderbuffertarget, int renderbuffer);
        [DllImport(Lib)] public static extern int glCheckFramebufferStatus(int target);

        [DllImport(Lib)] public static extern void glGenRenderbuffers(int n, int* renderbuffers);
        [DllImport(Lib)] public static extern void glDeleteRenderbuffers(int n, int* renderbuffers);
        [DllImport(Lib)] public static extern void glBindRenderbuffer(int target, int renderbuffer);
        [DllImport(Lib)] public static extern void glRenderbufferStorage(int target, int internalformat, int width, int height);

        // ---- shaders ---------------------------------------------------------------
        [DllImport(Lib)] public static extern int glCreateShader(int type);
        [DllImport(Lib)] public static extern void glShaderSource(int shader, int count, byte** str, int* length);
        [DllImport(Lib)] public static extern void glCompileShader(int shader);
        [DllImport(Lib)] public static extern void glGetShaderiv(int shader, int pname, int* @params);
        [DllImport(Lib)] public static extern void glGetShaderInfoLog(int shader, int bufSize, int* length, byte* infoLog);
        [DllImport(Lib)] public static extern void glDeleteShader(int shader);
        [DllImport(Lib)] public static extern int glCreateProgram();
        [DllImport(Lib)] public static extern void glAttachShader(int program, int shader);
        [DllImport(Lib)] public static extern void glLinkProgram(int program);
        [DllImport(Lib)] public static extern void glGetProgramiv(int program, int pname, int* @params);
        [DllImport(Lib)] public static extern void glGetProgramInfoLog(int program, int bufSize, int* length, byte* infoLog);
        [DllImport(Lib)] public static extern void glUseProgram(int program);
        [DllImport(Lib)] public static extern void glDeleteProgram(int program);
        [DllImport(Lib)] public static extern int glGetUniformLocation(int program, byte* name);
        [DllImport(Lib)] public static extern void glUniform1i(int location, int v0);
        [DllImport(Lib)] public static extern void glUniform2f(int location, float v0, float v1);
        [DllImport(Lib)] public static extern void glUniform4f(int location, float v0, float v1, float v2, float v3);
        [DllImport(Lib)] public static extern void glUniformMatrix4fv(int location, int count, byte transpose, float* value);

        // ---- drawing ---------------------------------------------------------------
        [DllImport(Lib)] public static extern void glEnableVertexAttribArray(int index);
        [DllImport(Lib)] public static extern void glDisableVertexAttribArray(int index);
        [DllImport(Lib)] public static extern void glVertexAttribPointer(int index, int size, int type, byte normalized, int stride, nint offset);
        [DllImport(Lib)] public static extern void glDrawArrays(int mode, int first, int count);
        [DllImport(Lib)] public static extern void glDrawElements(int mode, int count, int type, nint offset);
        [DllImport(Lib)] public static extern void glReadPixels(int x, int y, int width, int height, int format, int type, void* pixels);

        // ---- convenience wrappers --------------------------------------------------
        public static int GenBuffer() { int b; glGenBuffers(1, &b); return b; }
        public static void DeleteBuffer(int b) { glDeleteBuffers(1, &b); }
        public static int GenTexture() { int t; glGenTextures(1, &t); return t; }
        public static void DeleteTexture(int t) { glDeleteTextures(1, &t); }
        public static int GenFramebuffer() { int f; glGenFramebuffers(1, &f); return f; }
        public static void DeleteFramebuffer(int f) { glDeleteFramebuffers(1, &f); }
        public static int GenRenderbuffer() { int r; glGenRenderbuffers(1, &r); return r; }
        public static void DeleteRenderbuffer(int r) { glDeleteRenderbuffers(1, &r); }

        public static void BufferData(int target, float[] data, int floatCount, int usage)
        {
            fixed (float* p = data) glBufferData(target, (nint)(floatCount * sizeof(float)), p, usage);
        }

        public static void BufferData(int target, int[] data, int intCount, int usage)
        {
            fixed (int* p = data) glBufferData(target, (nint)(intCount * sizeof(int)), p, usage);
        }

        public static void UniformMatrix4(int location, float[] rowMajor16)
        {
            // Row-major data uploaded with transpose=false: see Matrix4 for why this is right.
            fixed (float* p = rowMajor16) glUniformMatrix4fv(location, 1, 0, p);
        }

        public static int GetUniformLocation(int program, string name)
        {
            byte[] bytes = Encoding.ASCII.GetBytes(name + "\0");
            fixed (byte* p = bytes) return glGetUniformLocation(program, p);
        }

        public static void VertexAttribPointerF(int index, int components, int strideBytes)
        {
            glVertexAttribPointer(index, components, FLOAT, 0, strideBytes, 0);
        }

        public static void TexImage2DRgba(int width, int height, byte[] pixelsOrNull)
        {
            if (pixelsOrNull == null)
            {
                glTexImage2D(TEXTURE_2D, 0, RGBA8, width, height, 0, RGBA, UNSIGNED_BYTE, null);
            }
            else
            {
                glPixelStorei(UNPACK_ALIGNMENT, 1);
                fixed (byte* p = pixelsOrNull)
                    glTexImage2D(TEXTURE_2D, 0, RGBA8, width, height, 0, RGBA, UNSIGNED_BYTE, p);
            }
        }

        public static void ReadPixelsRgba(int width, int height, IntPtr destination)
        {
            glPixelStorei(PACK_ALIGNMENT, 1);
            glReadPixels(0, 0, width, height, RGBA, UNSIGNED_BYTE, (void*)destination);
        }

        public static int CompileShader(int type, string source)
        {
            int shader = glCreateShader(type);
            byte[] bytes = Encoding.UTF8.GetBytes(source + "\0");
            fixed (byte* p = bytes)
            {
                byte* pp = p;
                glShaderSource(shader, 1, &pp, null);
            }
            glCompileShader(shader);
            int ok;
            glGetShaderiv(shader, COMPILE_STATUS, &ok);
            if (ok == 0)
            {
                string log = ShaderLog(shader, true);
                glDeleteShader(shader);
                throw new InvalidOperationException("GLSL compile error: " + log + "\n" + source);
            }
            return shader;
        }

        /// <summary>Compile + link a program.  Attribute locations come from layout(location=N) in the GLSL.</summary>
        public static int MakeProgram(string vertexSource, string fragmentSource)
        {
            int vs = CompileShader(VERTEX_SHADER, vertexSource);
            int fs = CompileShader(FRAGMENT_SHADER, fragmentSource);
            int program = glCreateProgram();
            glAttachShader(program, vs);
            glAttachShader(program, fs);
            glLinkProgram(program);
            int ok;
            glGetProgramiv(program, LINK_STATUS, &ok);
            glDeleteShader(vs);   // flagged for deletion, freed with the program
            glDeleteShader(fs);
            if (ok == 0)
            {
                string log = ShaderLog(program, false);
                glDeleteProgram(program);
                throw new InvalidOperationException("GLSL link error: " + log);
            }
            return program;
        }

        static string ShaderLog(int obj, bool isShader)
        {
            int len;
            if (isShader) glGetShaderiv(obj, INFO_LOG_LENGTH, &len);
            else glGetProgramiv(obj, INFO_LOG_LENGTH, &len);
            if (len <= 1) return "";
            byte[] buf = new byte[len];
            int written;
            fixed (byte* p = buf)
            {
                if (isShader) glGetShaderInfoLog(obj, len, &written, p);
                else glGetProgramInfoLog(obj, len, &written, p);
            }
            return Encoding.UTF8.GetString(buf, 0, Math.Max(0, Math.Min(written, len)));
        }

        public static void CheckError(string where)
        {
            int e = glGetError();
            if (e != NO_ERROR)
                Console.WriteLine("GL error 0x" + e.ToString("X") + " at " + where);
        }

        /// <summary>Quad index list for GL_TRIANGLES: quad q = vertices 4q..4q+3 -> (0,1,2)(0,2,3).</summary>
        public static int[] MakeQuadIndices(int quadCount)
        {
            var idx = new int[quadCount * 6];
            for (int q = 0; q < quadCount; q++)
            {
                int v = q * 4, i = q * 6;
                idx[i] = v; idx[i + 1] = v + 1; idx[i + 2] = v + 2;
                idx[i + 3] = v; idx[i + 4] = v + 2; idx[i + 5] = v + 3;
            }
            return idx;
        }
    }
}
