namespace ZenithEngine
{
    /// <summary>MIDITrail+ renderer settings (same fields and defaults as the desktop plugin).</summary>
    public class MidiTrailSettings
    {
        public int firstNote = 0;
        public int lastNote = 128;
        public double deltaTimeOnScreen = 400;
        public bool sameWidthNotes = true;

        public double FOV = 3.1415 / 3;
        public double viewHeight = 0.5;
        public double viewOffset = 0.4;
        public double viewPan = 0.0;
        public double camAng = 0.56;
        public double camRot = 0;
        public double camSpin = 0;
        public double viewdist = 14;
        public double viewback = 0.2;

        public bool verticalNotes = false;

        public double noteDownSpeed = 0.6;
        public double noteUpSpeed = 0.2;
        public bool boxNotes = false;
        public bool lightShade = false;
        public bool showKeyboard = true;

        public bool tiltKeys = true;

        public bool eatNotes = false;

        public string palette = "Random";

        public string selectedAuraImage = "ring";
        public double auraStrength = 2;
        public bool auraEnabled = true;

        public bool useVel = false;

        public bool notesChangeSize = false;
        public bool notesChangeTint = true;

        public float noteBrightness = 1;

        public bool tickBased = true;

        public MidiTrailSettings Clone() => (MidiTrailSettings)MemberwiseClone();

        /// <summary>The five camera presets from the desktop settings panel.</summary>
        public void ApplyPreset(string name)
        {
            double rad(double deg) => deg / 180 * System.Math.PI;
            switch (name)
            {
                case "Far":
                    Set(0.5, 0.4, 0, 60, 32.08, 0, 0, 14, 0.2); break;
                case "Medium":
                    Set(0.52, 0.37, 0, 60, 34.98, 0, 0, 5.52, 0.2); break;
                case "Close":
                    Set(0.55, 0.33, 0, 60, 39.62, 0, 0, 3.06, 0.2); break;
                case "Top":
                    Set(10, -3.77, -1.53, 26, 90, -90, 0, 7.93, 0.64); break;
                case "Perspective":
                    Set(0.67, 1.07, -0.32, 60, 33.24, -13.84, 0, 14, 0.98); break;
            }

            void Set(double h, double off, double pan, double fov, double ang, double rot, double spin, double dist, double back)
            {
                viewHeight = h; viewOffset = off; viewPan = pan;
                FOV = rad(fov); camAng = rad(ang); camRot = rad(rot); camSpin = rad(spin);
                viewdist = dist; viewback = back;
            }
        }
    }
}
