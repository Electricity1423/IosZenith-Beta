using System;

namespace Zenith.iOS.GL
{
    /// <summary>
    /// Full-screen quad in 0..1 coordinates (the vertex shader maps it to clip space).
    /// Replaces the desktop DrawScreenQuad, which used GL_QUADS and client arrays.
    /// </summary>
    internal sealed class ScreenQuad : IDisposable
    {
        int buffer;
        // same corner order as the desktop version: (0,0) (0,1) (1,1) (1,0)
        static readonly float[] Corners = { 0, 0, 0, 1, 1, 1, 1, 0 };

        public ScreenQuad()
        {
            buffer = Gl.GenBuffer();
            Gl.glBindBuffer(Gl.ARRAY_BUFFER, buffer);
            Gl.BufferData(Gl.ARRAY_BUFFER, Corners, Corners.Length, Gl.STATIC_DRAW);
        }

        /// <summary>Draw with the currently bound program and texture.  <paramref name="blend"/> selects SrcAlpha/OneMinusSrcAlpha blending, as the desktop did.</summary>
        public void Draw(bool blend)
        {
            if (blend)
            {
                Gl.glEnable(Gl.BLEND);
                Gl.glBlendFunc(Gl.SRC_ALPHA, Gl.ONE_MINUS_SRC_ALPHA);
            }
            else
            {
                Gl.glDisable(Gl.BLEND);
            }
            Gl.glEnableVertexAttribArray(0);
            Gl.glBindBuffer(Gl.ARRAY_BUFFER, buffer);
            Gl.VertexAttribPointerF(0, 2, 8);
            Gl.glDrawArrays(Gl.TRIANGLE_FAN, 0, 4);
            Gl.glDisableVertexAttribArray(0);
            Gl.glDisable(Gl.BLEND);
        }

        public void Dispose()
        {
            if (buffer != 0) Gl.DeleteBuffer(buffer);
            buffer = 0;
        }
    }
}
