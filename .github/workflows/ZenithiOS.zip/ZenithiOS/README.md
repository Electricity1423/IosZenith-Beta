# Zenith MIDI for iOS (MIDITrail+ only)

An iOS port of Zenith MIDI 2.1.5 containing only the **MIDITrail+** renderer, plus an in-process
build of **ffmpeg** for video export.

## Layout
- `ffmpeg-ios/` – ffmpeg n7.1.1 patch (library entry point), C wrapper (`zenith_ffmpeg.c`), host tests, and `scripts/build-ffmpeg-ios.sh` which produces `ZenithFFmpeg.xcframework`.
- `src/ZenithCore/` – platform-neutral engine (MIDI parsing, note engine, palettes, playback loop). Plain net8.0.
- `src/ZenithiOS/` – the iOS app (net8.0-ios): OpenGL ES 3 port of the renderer, post-processing, ffmpeg bindings, UIKit UI.

## Building (needs a Mac with Xcode and the .NET 8 SDK + `dotnet workload install ios`)
1. `cd ffmpeg-ios/scripts && ./build-ffmpeg-ios.sh`   (add `SLICES=device` for a quicker device-only build)
2. Set your bundle id / signing in `src/ZenithiOS/ZenithiOS.csproj` and `Info.plist`.
3. `dotnet build src/ZenithiOS -f net8.0-ios -c Release -r ios-arm64` (or open the csproj in Rider / Visual Studio).
   If the xcframework NativeReference gives trouble, point it at `ffmpeg-ios/out/ios-arm64/libZenithFFmpeg.a`.

## How it works
- iOS cannot spawn processes, so ffmpeg runs **in-process**: `main()` is renamed `zenith_ffmpeg_main`, global state is reset between runs, and frames are sent through a FIFO exactly like the desktop pipe to ffmpeg.exe.
- Rendering uses OpenGL ES 3 (triangles instead of quads, float attributes). The desktop maths and alpha pipeline are kept.
- H.264/HEVC use Apple's VideoToolbox encoders (no libx264, so the build stays LGPL and App-Store compatible). Desktop "CRF" is mapped approximately to VideoToolbox quality.
- Transparency-mask export uses a single FIFO with `alphaextract` (two FIFOs deadlock).
- Finished videos are saved to the app's Documents folder (visible in the Files app) and offered via the share sheet.

## What has and hasn't been tested
**Tested (Linux):** the patched ffmpeg running in-process – repeated runs, FIFO video input, audio, mask path, cancel and failure handling (`ffmpeg-ios/test/run-host-test.sh`, all passing).

**Not tested – no Mac, iOS SDK or C# compiler was available:** every C# file (only brace-balance checked), the iOS ffmpeg cross-build script (syntax-checked only), VideoToolbox option mapping (`-q:v`, `-maxrate`), and all on-device GL behaviour. Expect a round of compile fixes and some GL debugging on first build.

## Known limitations
- No audio during preview (export can mux an audio file); no Scripted plugin or other renderers.
- Export is foreground-only: iOS forbids GL in the background, so locking the phone pauses it.
- Very large MIDIs may hit iOS memory limits.
- OpenGL ES / GLKit are deprecated by Apple but still work; a Metal port would be the long-term path.
- The loaded MIDI keeps the settings from load time; preview/export use their own render settings.
