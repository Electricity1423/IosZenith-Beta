using System;
using UIKit;
using ZenithEngine;

namespace Zenith.iOS.UI
{
    /// <summary>All MIDITrail+ options (same set as the desktop settings panel).</summary>
    internal sealed class SettingsViewController : FormViewController
    {
        MidiTrailSettings t => SettingsStore.Current.Trail;

        public SettingsViewController() { Title = "MIDITrail+ settings"; }

        public override void ViewWillDisappear(bool animated)
        {
            base.ViewWillDisappear(animated);
            SettingsStore.Save();
        }

        protected override void Build()
        {
            AddHeader("Camera preset");
            AddButton("Choose preset…", () =>
            {
                var sheet = UIAlertController.Create("Camera preset", null, UIAlertControllerStyle.ActionSheet);
                foreach (var name in new[] { "Far", "Medium", "Close", "Top", "Perspective" })
                {
                    string n = name;
                    sheet.AddAction(UIAlertAction.Create(n, UIAlertActionStyle.Default, _ =>
                    {
                        t.ApplyPreset(n);
                        SettingsStore.Save();
                        RebuildAll();
                    }));
                }
                sheet.AddAction(UIAlertAction.Create("Cancel", UIAlertActionStyle.Cancel, null));
                if (sheet.PopoverPresentationController != null) sheet.PopoverPresentationController.SourceView = View;
                PresentViewController(sheet, true, null);
            });

            AddHeader("Notes");
            AddSlider("Time on screen (ms)", 50, 4000, t.deltaTimeOnScreen, "0", v => t.deltaTimeOnScreen = v);
            AddSwitch("Tick-based timing", t.tickBased, v => t.tickBased = v);
            AddSwitch("Same-width notes", t.sameWidthNotes, v => t.sameWidthNotes = v);
            AddSwitch("Box notes", t.boxNotes, v => t.boxNotes = v);
            AddSwitch("Light shading", t.lightShade, v => t.lightShade = v);
            AddSwitch("Vertical notes", t.verticalNotes, v => t.verticalNotes = v);
            AddSwitch("Eat notes", t.eatNotes, v => t.eatNotes = v);
            AddSwitch("Use velocity", t.useVel, v => t.useVel = v);
            AddSwitch("Notes change size", t.notesChangeSize, v => t.notesChangeSize = v);
            AddSwitch("Notes change tint", t.notesChangeTint, v => t.notesChangeTint = v);
            AddSlider("Note brightness", 0, 2, t.noteBrightness, "0.00", v => t.noteBrightness = (float)v);
            AddSlider("First key", 0, 127, t.firstNote, "0", v => t.firstNote = (int)Math.Round(v));
            AddSlider("Last key", 1, 128, t.lastNote, "0", v => t.lastNote = (int)Math.Round(v));

            AddHeader("Keyboard");
            AddSwitch("Show keyboard", t.showKeyboard, v => t.showKeyboard = v);
            AddSwitch("Tilt keys", t.tiltKeys, v => t.tiltKeys = v);
            AddSlider("Key down speed", 0.05, 2, t.noteDownSpeed, "0.00", v => t.noteDownSpeed = v);
            AddSlider("Key up speed", 0.05, 2, t.noteUpSpeed, "0.00", v => t.noteUpSpeed = v);

            AddHeader("Aura");
            AddSwitch("Key glow", t.auraEnabled, v => t.auraEnabled = v);
            AddSlider("Glow strength", 0, 6, t.auraStrength, "0.0", v => t.auraStrength = v);

            AddHeader("Camera");
            AddSlider("Field of view (°)", 20, 120, t.FOV / Math.PI * 180, "0", v => t.FOV = v / 180 * Math.PI);
            AddSlider("Height", -10, 12, t.viewHeight, "0.00", v => t.viewHeight = v);
            AddSlider("Offset", -6, 6, t.viewOffset, "0.00", v => t.viewOffset = v);
            AddSlider("Pan", -4, 4, t.viewPan, "0.00", v => t.viewPan = v);
            AddSlider("Angle (°)", 0, 90, t.camAng / Math.PI * 180, "0.0", v => t.camAng = v / 180 * Math.PI);
            AddSlider("Rotation (°)", -180, 180, t.camRot / Math.PI * 180, "0.0", v => t.camRot = v / 180 * Math.PI);
            AddSlider("Spin (°)", -180, 180, t.camSpin / Math.PI * 180, "0.0", v => t.camSpin = v / 180 * Math.PI);
            AddSlider("Distance", 1, 30, t.viewdist, "0.00", v => t.viewdist = v);
            AddSlider("View back", 0, 2, t.viewback, "0.00", v => t.viewback = v);

            AddHeader("Colours");
            var names = NotePalette.Names;
            AddSegmentedPalette(names);
        }

        void AddSegmentedPalette(string[] names)
        {
            int sel = Math.Max(0, Array.IndexOf(names, t.palette));
            var b = AddButton("Palette: " + names[sel], () => { });
            b.TouchUpInside += (s, e) =>
            {
                var sheet = UIAlertController.Create("Palette", null, UIAlertControllerStyle.ActionSheet);
                foreach (var n in names)
                {
                    string name = n;
                    sheet.AddAction(UIAlertAction.Create(name, UIAlertActionStyle.Default, _ =>
                    {
                        t.palette = name;
                        b.SetTitle("Palette: " + name, UIControlState.Normal);
                    }));
                }
                sheet.AddAction(UIAlertAction.Create("Cancel", UIAlertActionStyle.Cancel, null));
                if (sheet.PopoverPresentationController != null) sheet.PopoverPresentationController.SourceView = b;
                PresentViewController(sheet, true, null);
            };
        }

        void RebuildAll()
        {
            foreach (var v in Stack.ArrangedSubviews) { Stack.RemoveArrangedSubview(v); v.RemoveFromSuperview(); }
            Build();
        }
    }
}
