using System;
using System.Linq;
using System.Threading;

namespace ZenithEngine
{
    /// <summary>
    /// The playback logic that lives in RenderWindow.OnRenderFrame (frame loop, tempo and
    /// colour events) and MainWindow.RunRenderWindow (the note-collector thread) in the
    /// desktop program, with all windowing and GL removed.
    ///
    /// Usage (same thread that owns the GL context):
    ///     var pc = new PlaybackController(midi, settings, renderer);
    ///     settings.running = true;
    ///     pc.Begin();
    ///     while (pc.Step(finalCompositeBuffer, realtime)) { ...post-process / present / encode... }
    ///     pc.Dispose();
    ///     midi.Reset();
    /// </summary>
    public class PlaybackController : IDisposable
    {
        public readonly MidiFile Midi;
        readonly RenderSettings settings;
        readonly IMidiRenderer renderer;

        public double MidiTime;
        public double TempoFrameStep = 10;
        public double LastDeltaTimeOnScreen;
        public double LastMV = 1;

        double lastTempo;
        long frameStartTime;
        double microsecondsPerTick;
        int noNoteFrames;
        bool firstRenderer = true;
        Thread collector;

        public bool Finished { get; private set; }
        public Exception Error { get; private set; }

        public PlaybackController(MidiFile midi, RenderSettings settings, IMidiRenderer renderer)
        {
            Midi = midi;
            this.settings = settings;
            this.renderer = renderer;

            lastTempo = midi.zerothTempo;
            renderer.Tempo = 60000000.0 / midi.zerothTempo;
            MidiTime = -renderer.NoteScreenTime;
            if (settings.timeBasedNotes) TempoFrameStep = 1000.0 / settings.fps;
            else TempoFrameStep = ((double)midi.division / lastTempo) * (1000000 / settings.fps);   // (int division as in the original)
            MidiTime -= TempoFrameStep * settings.renderSecondsDelay * settings.fps;
        }

        /// <summary>0..1 position in the file.</summary>
        public double Progress
        {
            get
            {
                double p;
                if (settings.timeBasedNotes) p = MidiTime / 1000 / Midi.info.secondsLength;
                else p = MidiTime / Midi.maxTrackTime;
                if (double.IsNaN(p) || p < 0) return 0;
                return p > 1 ? 1 : p;
            }
        }

        /// <summary>Call once, after settings.running = true, before the first Step.</summary>
        public void Begin()
        {
            if (!settings.timeBasedNotes) TempoFrameStep = ((double)Midi.division / lastTempo) * (1000000.0 / settings.fps);
            LastDeltaTimeOnScreen = renderer.NoteScreenTime;
            renderer.CurrentMidi = Midi.info;
            noNoteFrames = 0;
            frameStartTime = DateTime.Now.Ticks;
            if (settings.timeBasedNotes) microsecondsPerTick = 10000;
            else microsecondsPerTick = (long)((double)lastTempo / Midi.division * 10);

            collector = new Thread(CollectorLoop) { IsBackground = true, Name = "Zenith note collector" };
            collector.Start();
        }

        /// <summary>
        /// Render one frame into <paramref name="finalCompositeBuff"/> and advance time.
        /// Returns false when the song has finished (or settings.running was cleared).
        /// <paramref name="realtime"/>: advance by elapsed wall-clock time (preview) instead of
        /// exactly one frame (video export).
        /// </summary>
        public bool Step(int finalCompositeBuff, bool realtime)
        {
            if (!(settings.running && (noNoteFrames < settings.fps * 5 || Midi.unendedTracks != 0)))
            {
                Finished = true;
                return false;
            }

            if (!settings.Paused || settings.forceReRender)
            {
                if (!renderer.Initialized)
                {
                    renderer.Init();
                    renderer.NoteColors = Midi.tracks.Select(t => t.trkColors).ToArray();
                    renderer.ReloadTrackColors();
                    if (firstRenderer)
                    {
                        firstRenderer = false;
                        Midi.SetZeroColors();
                    }
                    renderer.CurrentMidi = Midi.info;
                    lock (Midi.globalDisplayNotes)
                    {
                        foreach (Note n in Midi.globalDisplayNotes) n.meta = null;
                    }
                }
                renderer.Tempo = 60000000.0 / lastTempo;
                LastDeltaTimeOnScreen = renderer.NoteScreenTime;

                // wait for the parser thread to be far enough ahead
                if (settings.timeBasedNotes)
                    SpinWait.SpinUntil(() => (Midi.currentFlexSyncTime > MidiTime + LastDeltaTimeOnScreen + TempoFrameStep * settings.tempoMultiplier || Midi.unendedTracks == 0) || !settings.running);
                else
                    SpinWait.SpinUntil(() => (Midi.currentSyncTime > MidiTime + LastDeltaTimeOnScreen + TempoFrameStep * settings.tempoMultiplier || Midi.unendedTracks == 0) || !settings.running);
                if (!settings.running)
                {
                    Finished = true;
                    return false;
                }

                renderer.RenderFrame(Midi.globalDisplayNotes, MidiTime, finalCompositeBuff);
                long lastNC = renderer.LastNoteCount;
                if (lastNC == 0 && Midi.unendedTracks == 0) noNoteFrames++;
                else noNoteFrames = 0;
            }

            AdvanceTime(realtime);
            return true;
        }

        void AdvanceTime(bool realtime)
        {
            double mv = 1;
            if (realtime && settings.realtimePlayback)
            {
                mv = (DateTime.Now.Ticks - frameStartTime) / microsecondsPerTick / TempoFrameStep;
                if (mv > settings.fps / 4)
                    mv = settings.fps / 4;
            }
            LastMV = mv;

            if (!settings.Paused)
            {
                lock (Midi.globalTempoEvents)
                {
                    while (Midi.globalTempoEvents.First != null && MidiTime + (TempoFrameStep * mv * settings.tempoMultiplier) > Midi.globalTempoEvents.First.pos)
                    {
                        var t = Midi.globalTempoEvents.Pop();
                        if (t.tempo == 0)
                        {
                            Console.WriteLine("Zero tempo event encountered, ignoring");
                            continue;
                        }
                        var _t = ((t.pos) - MidiTime) / (TempoFrameStep * mv * settings.tempoMultiplier);
                        mv *= 1 - _t;
                        if (!settings.timeBasedNotes) TempoFrameStep = ((double)Midi.division / t.tempo) * (1000000.0 / settings.fps);
                        lastTempo = t.tempo;
                        MidiTime = t.pos;
                    }
                }
                MidiTime += mv * TempoFrameStep * settings.tempoMultiplier;
            }
            frameStartTime = DateTime.Now.Ticks;
            if (settings.timeBasedNotes) microsecondsPerTick = 10000;
            else microsecondsPerTick = (long)(lastTempo / Midi.division * 10);

            while (Midi.globalColorEvents.First != null && Midi.globalColorEvents.First.pos < MidiTime)
            {
                var c = Midi.globalColorEvents.Pop();
                if (!settings.ignoreColorEvents)
                {
                    if (c.channel == 0x7F)
                    {
                        for (int i = 0; i < 16; i++)
                        {
                            c.track.trkColors[i].left = c.col1;
                            c.track.trkColors[i].right = c.col2;
                            c.track.trkColors[i].isDefault = false;
                        }
                    }
                    else
                    {
                        c.track.trkColors[c.channel].left = c.col1;
                        c.track.trkColors[c.channel].right = c.col2;
                        c.track.trkColors[c.channel].isDefault = false;
                    }
                }
            }
        }

        /// <summary>Jump forward by roughly <paramref name="ms"/> milliseconds of song time (preview only).</summary>
        public void SkipForward(int ms)
        {
            if (settings.timeBasedNotes) { MidiTime += ms; return; }
            lock (Midi)
            {
                double timeSkipped = 0;
                for (; timeSkipped < ms; MidiTime++)
                {
                    Midi.ParseUpTo(MidiTime);
                    timeSkipped += 1 / Midi.tempoTickMultiplier;
                }
            }
        }

        // ---- note collector thread (MainWindow.RunRenderWindow) ----------------------
        void CollectorLoop()
        {
            long nc = -1;
            try
            {
                while (TryParse(nc))
                {
                    if (!settings.running) break;
                    double cutoffTime = MidiTime;
                    bool manualDelete = renderer.ManualNoteDelete;
                    cutoffTime += renderer.NoteCollectorOffset;
                    if (!settings.running) break;
                    lock (Midi.globalDisplayNotes)
                    {
                        var i = Midi.globalDisplayNotes.Iterate();
                        Note n;
                        if (manualDelete)
                        {
                            while (i.MoveNext(out n))
                            {
                                if (n.delete) i.Remove();
                                else nc++;
                            }
                        }
                        else
                        {
                            while (i.MoveNext(out n))
                            {
                                if (n.hasEnded && n.end < cutoffTime)
                                    i.Remove();
                                if (n.start > cutoffTime) break;
                            }
                        }
                    }
                    double lastWinTime = MidiTime;
                    SpinWait.SpinUntil(() =>
                        (MidiTime + LastDeltaTimeOnScreen + (TempoFrameStep * 10 * settings.tempoMultiplier * (LastMV > 1 ? LastMV : 1))) > Midi.currentSyncTime
                        || lastWinTime != MidiTime || !settings.running);
                }
            }
            catch (Exception ex)
            {
                Error = ex;
                Console.WriteLine(ex);
                settings.running = false;
            }
        }

        bool TryParse(long nc)
        {
            lock (Midi)
            {
                return (Midi.ParseUpTo(
                    MidiTime + LastDeltaTimeOnScreen +
                    (TempoFrameStep * 20 * settings.tempoMultiplier * (LastMV > 1 ? LastMV : 1)))
                    || nc != 0) && settings.running;
            }
        }

        public void Dispose()
        {
            settings.running = false;
            var t = collector;
            collector = null;
            if (t != null && t.IsAlive && Thread.CurrentThread != t) t.Join(3000);
        }
    }
}
