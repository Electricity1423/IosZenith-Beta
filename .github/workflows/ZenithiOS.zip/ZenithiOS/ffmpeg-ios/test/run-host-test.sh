#!/usr/bin/env bash
# Builds a minimal ffmpeg on a Linux/macOS *host*, applies the Zenith patch,
# and runs test_runner.c against it.  This checks the in-process entry point
# (patch + zenith_ffmpeg.c) without needing Xcode or an iPhone.
#
#   ./run-host-test.sh [work-dir]      (default: ./host-test-work)
set -euo pipefail

FFMPEG_TAG="${FFMPEG_TAG:-n7.1.1}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$HERE/.." && pwd)"
WORK="$(mkdir -p "${1:-$PWD/host-test-work}" && cd "${1:-$PWD/host-test-work}" && pwd)"
JOBS="${JOBS:-$(nproc 2>/dev/null || sysctl -n hw.ncpu)}"

if [ ! -d "$WORK/ffmpeg" ]; then
  git clone --depth 1 --branch "$FFMPEG_TAG" https://github.com/FFmpeg/FFmpeg.git "$WORK/ffmpeg"
  git -C "$WORK/ffmpeg" apply "$ROOT/patches/0001-zenith-library-entry.patch"
fi

mkdir -p "$WORK/build" && cd "$WORK/build"
if [ ! -f config.h ]; then
  ../ffmpeg/configure --disable-everything --disable-doc --disable-ffplay --disable-ffprobe \
    --disable-network --disable-autodetect --disable-avdevice --disable-debug --enable-pic \
    --enable-protocol=file,pipe --enable-demuxer=rawvideo,mov,wav \
    --enable-muxer=mp4,mov,null,wav \
    --enable-encoder=mpeg4,rawvideo,aac,pcm_s16le,wrapped_avframe \
    --enable-decoder=rawvideo,mpeg4,pcm_s16le,aac --enable-parser=mpeg4video,aac \
    --enable-filter=vflip,format,scale,aresample,anull,null,aformat,nullsink,anullsink,split,alphaextract \
    --enable-bsf=aac_adtstoasc,null
fi

CLI_OBJS="fftools/ffmpeg.o fftools/ffmpeg_dec.o fftools/ffmpeg_demux.o fftools/ffmpeg_enc.o
 fftools/ffmpeg_filter.o fftools/ffmpeg_hw.o fftools/ffmpeg_mux.o fftools/ffmpeg_mux_init.o
 fftools/ffmpeg_opt.o fftools/ffmpeg_sched.o fftools/objpool.o fftools/sync_queue.o
 fftools/thread_queue.o fftools/cmdutils.o fftools/opt_common.o"
LIBS="libavfilter/libavfilter.a libavformat/libavformat.a
 libavcodec/libavcodec.a libswscale/libswscale.a libswresample/libswresample.a libavutil/libavutil.a"

make -j"$JOBS" $LIBS $CLI_OBJS
${CC:-cc} -O1 -g -Wall -I"$ROOT/src" -I. -I../ffmpeg \
  "$ROOT/test/test_runner.c" "$ROOT/src/zenith_ffmpeg.c" $CLI_OBJS $LIBS -lm -lpthread -o test_runner

rm -rf testwork
./test_runner "$PWD/testwork"
