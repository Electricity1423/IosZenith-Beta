using System;
using CoreGraphics;
using Foundation;
using UIKit;

namespace Zenith.iOS.UI
{
    /// <summary>A scrolling vertical form built from a few simple row types.</summary>
    internal class FormViewController : UIViewController
    {
        protected UIStackView Stack { get; private set; }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();
            View.BackgroundColor = UIColor.SystemBackground;

            var scroll = new UIScrollView { TranslatesAutoresizingMaskIntoConstraints = false, AlwaysBounceVertical = true };
            scroll.KeyboardDismissMode = UIScrollViewKeyboardDismissMode.OnDrag;
            View.AddSubview(scroll);

            Stack = new UIStackView
            {
                Axis = UILayoutConstraintAxis.Vertical,
                Spacing = 14,
                TranslatesAutoresizingMaskIntoConstraints = false,
                LayoutMarginsRelativeArrangement = true,
                LayoutMargins = new UIEdgeInsets(16, 16, 32, 16),
            };
            scroll.AddSubview(Stack);

            NSLayoutConstraint.ActivateConstraints(new[]
            {
                scroll.TopAnchor.ConstraintEqualTo(View.SafeAreaLayoutGuide.TopAnchor),
                scroll.BottomAnchor.ConstraintEqualTo(View.BottomAnchor),
                scroll.LeadingAnchor.ConstraintEqualTo(View.LeadingAnchor),
                scroll.TrailingAnchor.ConstraintEqualTo(View.TrailingAnchor),
                Stack.TopAnchor.ConstraintEqualTo(scroll.ContentLayoutGuide.TopAnchor),
                Stack.BottomAnchor.ConstraintEqualTo(scroll.ContentLayoutGuide.BottomAnchor),
                Stack.LeadingAnchor.ConstraintEqualTo(scroll.FrameLayoutGuide.LeadingAnchor),
                Stack.TrailingAnchor.ConstraintEqualTo(scroll.FrameLayoutGuide.TrailingAnchor),
            });

            Build();
        }

        protected virtual void Build() { }

        protected UILabel AddHeader(string text)
        {
            var l = new UILabel { Text = text.ToUpperInvariant(), Font = UIFont.BoldSystemFontOfSize(13), TextColor = UIColor.SecondaryLabel };
            Stack.AddArrangedSubview(l);
            Stack.SetCustomSpacing(6, l);
            return l;
        }

        protected UILabel AddNote(string text)
        {
            var l = new UILabel { Text = text, Font = UIFont.SystemFontOfSize(13), TextColor = UIColor.SecondaryLabel, Lines = 0 };
            Stack.AddArrangedSubview(l);
            return l;
        }

        protected UISwitch AddSwitch(string title, bool value, Action<bool> set)
        {
            var sw = new UISwitch { On = value };
            sw.ValueChanged += (s, e) => set(sw.On);
            var label = new UILabel { Text = title, Lines = 0 };
            var row = new UIStackView(new UIView[] { label, sw }) { Axis = UILayoutConstraintAxis.Horizontal, Spacing = 12, Alignment = UIStackViewAlignment.Center };
            label.SetContentHuggingPriority(250, UILayoutConstraintAxis.Horizontal);
            Stack.AddArrangedSubview(row);
            return sw;
        }

        protected UISlider AddSlider(string title, double min, double max, double value, string format, Action<double> set)
        {
            var label = new UILabel { Font = UIFont.SystemFontOfSize(15) };
            string Text(double v) => title + ": " + v.ToString(format, System.Globalization.CultureInfo.InvariantCulture);
            label.Text = Text(value);
            var slider = new UISlider { MinValue = (float)min, MaxValue = (float)max, Value = (float)Math.Max(min, Math.Min(max, value)) };
            slider.ValueChanged += (s, e) => { label.Text = Text(slider.Value); set(slider.Value); };
            var box = new UIStackView(new UIView[] { label, slider }) { Axis = UILayoutConstraintAxis.Vertical, Spacing = 2 };
            Stack.AddArrangedSubview(box);
            return slider;
        }

        protected UISegmentedControl AddSegmented(string title, string[] items, int selected, Action<int> set)
        {
            var label = new UILabel { Text = title, Font = UIFont.SystemFontOfSize(15) };
            var seg = new UISegmentedControl(items) { SelectedSegment = selected };
            seg.ValueChanged += (s, e) => set((int)seg.SelectedSegment);
            Stack.AddArrangedSubview(new UIStackView(new UIView[] { label, seg }) { Axis = UILayoutConstraintAxis.Vertical, Spacing = 4 });
            return seg;
        }

        protected UIButton AddButton(string title, Action tap, bool prominent = false)
        {
            var b = UIButton.FromType(UIButtonType.System);
            b.SetTitle(title, UIControlState.Normal);
            b.TitleLabel.Font = UIFont.BoldSystemFontOfSize(17);
            if (prominent)
            {
                b.BackgroundColor = UIColor.SystemBlue;
                b.SetTitleColor(UIColor.White, UIControlState.Normal);
                b.Layer.CornerRadius = 10;
            }
            else
            {
                b.BackgroundColor = UIColor.SecondarySystemBackground;
                b.Layer.CornerRadius = 10;
            }
            b.HeightAnchor.ConstraintEqualTo(48).Active = true;
            b.TouchUpInside += (s, e) => tap();
            Stack.AddArrangedSubview(b);
            return b;
        }

        protected void Alert(string title, string message)
        {
            var a = UIAlertController.Create(title, message, UIAlertControllerStyle.Alert);
            a.AddAction(UIAlertAction.Create("OK", UIAlertActionStyle.Default, null));
            PresentViewController(a, true, null);
        }
    }
}
