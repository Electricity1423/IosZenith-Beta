using System;
using ZenithEngine;

namespace Zenith.iOS.GL
{
    /// <summary>
    /// The post-processing chain of the desktop RenderWindow:
    ///   renderer -> finalComposite -> (downscale / SSAA) -> downscaleBuff
    ///            -> output buffer (read back for ffmpeg)  and/or  the screen.
    /// All the alpha handling (the sqrt(alpha) / divide-by-alpha trick) is kept exactly.
    /// </summary>
    internal sealed class PostPipeline : IDisposable
    {
        const string Vert = @"#version 300 es
layout(location = 0) in vec2 position;
out vec2 UV;
void main()
{
    gl_Position = vec4(position.x * 2.0 - 1.0, position.y * 2.0 - 1.0, 0.0, 1.0);
    UV = position;
}
";
        const string FragHeader = @"#version 300 es
precision highp float;
in vec2 UV;
out vec4 color;
uniform sampler2D TextureSampler;
";
        const string FragPost = FragHeader + @"
void main()
{
    color = texture(TextureSampler, UV);
    color.a = sqrt(color.a);
    if (color.a > 0.0) color.rgb /= color.a;
}
";
        const string FragDownscale = FragHeader + @"
uniform vec2 res;
uniform int factor;
void main()
{
    color = vec4(0.0, 0.0, 0.0, 0.0);
    float f = float(factor);
    float stepX = 1.0 / res.x / f;
    float stepY = 1.0 / res.y / f;
    for (int i = 0; i < factor; i += 1) {
        for (int j = 0; j < factor; j += 1) {
            color += texture(TextureSampler, UV + vec2(float(i) * stepX, float(j) * stepY));
        }
    }
    color /= f * f;
}
";
        // un-premultiply, keep alpha: RGB = straight colour, A = mask.  One readback gives
        // both the colour video and (through ffmpeg's alphaextract) the transparency-mask video.
        const string FragColorWithMask = FragHeader + @"
void main()
{
    color = texture(TextureSampler, UV);
    if (color.a > 0.0) color.rgb /= color.a;
}
";
        const string FragBlack = FragHeader + @"
void main()
{
    color = vec4(0.0, 0.0, 0.0, 1.0);
}
";
        // the plain copy used by MIDITrail+ to draw its 3D buffer into the composite buffer
        const string FragCopy = FragHeader + @"
void main()
{
    color = texture(TextureSampler, UV);
}
";

        readonly RenderSettings settings;
        readonly ScreenQuad quad = new ScreenQuad();

        readonly PostBuffer finalComposite;
        readonly PostBuffer downscale;
        readonly PostBuffer output;

        readonly int progPost, progDownscale, progColorMask, progBlack;
        readonly int uDownscaleRes, uDownscaleFac;

        public int FinalCompositeBuffer => finalComposite.BufferID;
        public int OutputWidth => settings.width / settings.downscale;
        public int OutputHeight => settings.height / settings.downscale;
        public int OutputByteCount => OutputWidth * OutputHeight * 4;

        public PostPipeline(RenderSettings settings, bool needsOutputBuffer)
        {
            this.settings = settings;
            int ow = settings.width / settings.downscale;
            int oh = settings.height / settings.downscale;

            finalComposite = new PostBuffer(settings.width, settings.height);
            downscale = new PostBuffer(ow, oh);
            if (needsOutputBuffer) output = new PostBuffer(ow, oh);

            progPost = Gl.MakeProgram(Vert, FragPost);
            progDownscale = Gl.MakeProgram(Vert, FragDownscale);
            progColorMask = Gl.MakeProgram(Vert, FragColorWithMask);
            progBlack = Gl.MakeProgram(Vert, FragBlack);
            uDownscaleRes = Gl.GetUniformLocation(progDownscale, "res");
            uDownscaleFac = Gl.GetUniformLocation(progDownscale, "factor");
        }

        /// <summary>Run after the renderer has drawn into FinalCompositeBuffer.</summary>
        public void Downscale()
        {
            int ow = OutputWidth, oh = OutputHeight;
            downscale.BindBuffer();
            Gl.glClear(Gl.COLOR_BUFFER_BIT);
            Gl.glViewport(0, 0, ow, oh);

            if (settings.downscale > 1)
            {
                Gl.glUseProgram(progDownscale);
                Gl.glUniform1i(uDownscaleFac, settings.downscale);
                Gl.glUniform2f(uDownscaleRes, ow, oh);
            }
            else
            {
                Gl.glUseProgram(progPost);
            }
            finalComposite.BindTexture();
            quad.Draw(true);
        }

        /// <summary>
        /// Render the frame handed to ffmpeg and copy it to <paramref name="destination"/>
        /// (RGBA, bottom row first - ffmpeg flips it with -vf vflip).
        /// </summary>
        public void ReadFrame(IntPtr destination)
        {
            if (output == null) throw new InvalidOperationException("pipeline was created without an output buffer");
            int ow = OutputWidth, oh = OutputHeight;
            output.BindBuffer();
            Gl.glClear(Gl.COLOR_BUFFER_BIT);
            Gl.glViewport(0, 0, ow, oh);
            downscale.BindTexture();
            if (settings.ffRenderMask)
            {
                Gl.glUseProgram(progColorMask);
                quad.Draw(false);
            }
            else
            {
                Gl.glUseProgram(progPost);
                quad.Draw(true);
            }
            Gl.ReadPixelsRgba(ow, oh, destination);
        }

        /// <summary>
        /// Draw the result into the currently bound framebuffer (the screen), letterboxed to the
        /// video's aspect ratio on black.
        /// </summary>
        public void Present(int targetWidth, int targetHeight)
        {
            Gl.glViewport(0, 0, targetWidth, targetHeight);
            Gl.glClear(Gl.COLOR_BUFFER_BIT);
            Gl.glUseProgram(progBlack);
            quad.Draw(true);

            double aspect = (double)settings.width / settings.height;
            int w = targetWidth;
            int h = (int)(w / aspect);
            if (h > targetHeight)
            {
                h = targetHeight;
                w = (int)(h * aspect);
            }
            Gl.glViewport((targetWidth - w) / 2, (targetHeight - h) / 2, w, h);
            Gl.glUseProgram(progPost);
            downscale.BindTexture();
            quad.Draw(true);
            Gl.glBindTexture(Gl.TEXTURE_2D, 0);
        }

        public void Dispose()
        {
            finalComposite.Dispose();
            downscale.Dispose();
            output?.Dispose();
            quad.Dispose();
            Gl.glDeleteProgram(progPost);
            Gl.glDeleteProgram(progDownscale);
            Gl.glDeleteProgram(progColorMask);
            Gl.glDeleteProgram(progBlack);
        }

        public static string CopyFragmentShader => FragCopy;
        public static string CopyVertexShader => Vert;
    }
}
