using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using OpenGLES;
using Zenith.iOS.GL;
using Zenith.iOS.Render;
using ZenithEngine;

namespace Zenith.iOS.Export
{
    internal sealed class ExportOptions
    {
        public string OutputPath;
        public string MaskOutputPath;        // null = no transparency-mask video
        public string AudioPath;             // null = no audio
        public int Width = 1920, Height = 1080;
        public int Ssaa = 1;                 // 1 = off, 2 = render at 2x and downscale
        public int Fps = 60;
        public int BitrateKbps = 20000;
        public bool UseBitrate = true;
        public int Crf = 17;
        public bool Hevc = false;
        public double TempoMultiplier = 1;
    }

    internal sealed class ExportResult
    {
        public bool Success;
        public bool Cancelled;
        public string Message;
        public string FfmpegLog;
    }

    /// <summary>
    /// Renders a MIDI file with MIDITrail+ and pipes the frames into the in-process ffmpeg through a FIFO,
    /// the iOS equivalent of the desktop "write raw frames to ffmpeg.exe's stdin".
    /// Run <see cref="Run"/> on a dedicated background thread.
    /// </summary>
    internal sealed class VideoExporter
    {
        public volatile bool CancelRequested;

        public event Action<double, double> ProgressChanged;   // progress 0..1, frames per second

        public static List<string> BuildArguments(ExportOptions o, string fifoPath, double audioOffsetSeconds)
        {
            var ci = CultureInfo.InvariantCulture;
            int ow = o.Width, oh = o.Height;
            var a = new List<string> { "-hide_banner", "-nostdin", "-y",
                "-f", "rawvideo", "-s", ow + "x" + oh, "-pix_fmt", "rgba",
                "-r", o.Fps.ToString(ci), "-i", fifoPath };

            bool audio = !string.IsNullOrEmpty(o.AudioPath);
            bool mask = !string.IsNullOrEmpty(o.MaskOutputPath);
            if (audio)
            {
                a.Add("-itsoffset"); a.Add(audioOffsetSeconds.ToString("0.##", ci));
                a.Add("-i"); a.Add(o.AudioPath);
            }

            if (mask)
            {
                // one pipe, two videos: the frame's RGB is the picture, its alpha is the mask
                a.Add("-filter_complex"); a.Add("[0:v]vflip,split=2[c][a];[a]alphaextract[m]");
                a.Add("-map"); a.Add("[c]");
            }
            else
            {
                a.Add("-vf"); a.Add("vflip");
            }
            if (audio) { a.Add("-map"); a.Add("1:a"); a.Add("-c:a"); a.Add("aac"); }

            AddVideoCodecArgs(a, o);
            a.Add("-pix_fmt"); a.Add("yuv420p");
            a.Add("-movflags"); a.Add("+faststart");
            a.Add(o.OutputPath);

            if (mask)
            {
                a.Add("-map"); a.Add("[m]");
                AddVideoCodecArgs(a, o);
                a.Add("-pix_fmt"); a.Add("yuv420p");
                a.Add("-movflags"); a.Add("+faststart");
                a.Add(o.MaskOutputPath);
            }
            return a;
        }

        static void AddVideoCodecArgs(List<string> a, ExportOptions o)
        {
            var ci = CultureInfo.InvariantCulture;
            a.Add("-c:v"); a.Add(o.Hevc ? "hevc_videotoolbox" : "h264_videotoolbox");
            if (o.Hevc) { a.Add("-tag:v"); a.Add("hvc1"); }
            if (o.UseBitrate)
            {
                a.Add("-b:v"); a.Add(o.BitrateKbps + "k");
                a.Add("-maxrate"); a.Add(o.BitrateKbps + "k");
            }
            else
            {
                // VideoToolbox has no CRF.  Map the familiar 0..51 scale onto its 1..100 quality scale.
                int q = Math.Max(1, Math.Min(100, 100 - o.Crf * 2));
                a.Add("-q:v"); a.Add(q.ToString(ci));
            }
        }

        public ExportResult Run(MidiFile midi, ExportOptions o, MidiTrailSettings trail, AuraImage aura)
        {
            string tmp = Path.GetTempPath();
            string fifo = Path.Combine(tmp, "zenith_video.fifo");
            EAGLContext ctx = null;
            RenderSession session = null;
            int fd = -1;
            IntPtr[] buffers = new IntPtr[2];
            Thread writer = null;
            var result = new ExportResult();
            bool writeFailed = false;

            try
            {
                if (FFmpegNative.IsRunning) return Fail(result, "ffmpeg is already running");

                var rs = new RenderSettings
                {
                    fps = o.Fps,
                    width = o.Width * o.Ssaa,
                    height = o.Height * o.Ssaa,
                    downscale = o.Ssaa,
                    ffRender = true,
                    ffRenderMask = !string.IsNullOrEmpty(o.MaskOutputPath),
                    realtimePlayback = false,
                    tempoMultiplier = o.TempoMultiplier,
                };

                ctx = new EAGLContext(EAGLRenderingAPI.OpenGLES3);
                if (!EAGLContext.SetCurrentContext(ctx)) return Fail(result, "Could not create an OpenGL ES 3 context");

                session = new RenderSession(midi, rs, trail, aura, true);

                // where the audio has to start so it lines up with the first note (same formula as the desktop version)
                double fstep = ((double)midi.division / midi.zerothTempo) * (1000000 / rs.fps);
                double offset = -session.MidiTimeTicks / fstep / rs.fps;
                offset = Math.Round(offset * 100) / 100;

                var args = BuildArguments(o, fifo, offset);
                FFmpegNative.SetLogLevel(FFmpegNative.LogInfo);
                FFmpegNative.ReadLog();
                if (!FFmpegNative.MakeFifo(fifo)) return Fail(result, "Could not create the frame pipe");
                if (!FFmpegNative.Start(args.ToArray())) return Fail(result, "Could not start ffmpeg");

                fd = FFmpegNative.OpenFifoWriter(fifo, 20000);
                if (fd < 0)
                {
                    FFmpegNative.Wait();
                    result.FfmpegLog = FFmpegNative.ReadLog();
                    return Fail(result, "ffmpeg did not start encoding. Check the options (e.g. audio file or output path).");
                }

                int frameBytes = session.FrameByteCount;
                for (int i = 0; i < 2; i++) buffers[i] = Marshal.AllocHGlobal(frameBytes);

                // writer thread: lets the GPU render frame N+1 while ffmpeg is still reading frame N
                var free = new SemaphoreSlim(2, 2);
                var queue = new BlockingCollection<int>();
                int fdLocal = fd;
                writer = new Thread(() =>
                {
                    foreach (int i in queue.GetConsumingEnumerable())
                    {
                        if (!FFmpegNative.WriteFully(fdLocal, buffers[i], frameBytes)) writeFailed = true;
                        free.Release();
                    }
                }) { IsBackground = true, Name = "Zenith frame writer" };
                writer.Start();

                int bi = 0;
                long frames = 0;
                var clock = System.Diagnostics.Stopwatch.StartNew();
                while (!CancelRequested && !writeFailed)
                {
                    if (!AppLifecycle.Active.IsSet)
                    {
                        Gl.glFinish();
                        AppLifecycle.Active.Wait();
                    }
                    if (!session.Step(false)) break;
                    free.Wait();
                    if (writeFailed) break;
                    session.ReadFrame(buffers[bi]);
                    queue.Add(bi);
                    bi ^= 1;
                    frames++;
                    if (frames % 10 == 0)
                        ProgressChanged?.Invoke(session.Progress, frames / Math.Max(0.001, clock.Elapsed.TotalSeconds));
                }

                queue.CompleteAdding();
                writer.Join();
                FFmpegNative.CloseFd(fd);       // tells ffmpeg the video is complete
                fd = -1;

                int rc = FFmpegNative.Wait();
                result.FfmpegLog = FFmpegNative.ReadLog();
                result.Cancelled = CancelRequested;
                if (session.Error != null) return Fail(result, "Rendering failed: " + session.Error.Message);
                if (CancelRequested) { result.Success = rc == 0; result.Message = "Cancelled (partial video kept)"; return result; }
                if (writeFailed || rc != 0) return Fail(result, "ffmpeg reported an error (code " + rc + ")");
                result.Success = true;
                result.Message = "Done: " + frames + " frames";
                ProgressChanged?.Invoke(1, frames / Math.Max(0.001, clock.Elapsed.TotalSeconds));
                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                if (FFmpegNative.IsRunning) { FFmpegNative.Cancel(); }
                return Fail(result, ex.Message);
            }
            finally
            {
                if (fd >= 0) FFmpegNative.CloseFd(fd);
                if (FFmpegNative.IsRunning) { FFmpegNative.Cancel(); FFmpegNative.Wait(); }
                foreach (var p in buffers) if (p != IntPtr.Zero) Marshal.FreeHGlobal(p);
                try { session?.Dispose(); } catch (Exception e) { Console.WriteLine(e); }
                try { File.Delete(fifo); } catch { }
                EAGLContext.SetCurrentContext(null);
                ctx?.Dispose();
            }
        }

        static ExportResult Fail(ExportResult r, string message)
        {
            r.Success = false;
            r.Message = message;
            return r;
        }
    }
}
