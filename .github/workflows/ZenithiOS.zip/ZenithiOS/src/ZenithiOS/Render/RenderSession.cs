using System;
using Zenith.iOS.GL;
using ZenithEngine;

namespace Zenith.iOS.Render
{
    /// <summary>
    /// One playback of one MIDI file through MIDITrail+: owns the renderer, the post-processing
    /// pipeline and the playback loop.  Create it, use it and dispose it on the thread that owns
    /// the current EAGLContext.
    /// </summary>
    internal sealed class RenderSession : IDisposable
    {
        readonly MidiFile midi;
        readonly MidiTrailRenderer renderer;
        readonly PostPipeline pipeline;
        readonly PlaybackController playback;
        bool disposed;

        public RenderSettings Settings { get; }
        public MidiTrailSettings TrailSettings => renderer.Settings;

        public RenderSession(MidiFile midi, RenderSettings settings, MidiTrailSettings trailSettings, AuraImage aura, bool forEncode)
        {
            this.midi = midi;
            Settings = settings;

            midi.Reset();   // always start from the beginning

            pipeline = new PostPipeline(settings, forEncode);
            renderer = new MidiTrailRenderer(settings, trailSettings);
            if (aura != null)
            {
                renderer.AuraRgba = aura.Rgba;
                renderer.AuraWidth = aura.Width;
                renderer.AuraHeight = aura.Height;
                renderer.AuraVersion++;
            }
            playback = new PlaybackController(midi, settings, renderer);

            settings.running = true;
            playback.Begin();
        }

        public double Progress => playback.Progress;
        public double MidiTimeTicks => playback.MidiTime;
        public double TempoFrameStep => playback.TempoFrameStep;
        public long NotesOnScreen => renderer.LastNoteCount;
        public Exception Error => playback.Error;

        /// <summary>Render and advance one frame.  False when the song is over.</summary>
        public bool Step(bool realtime)
        {
            if (!playback.Step(pipeline.FinalCompositeBuffer, realtime)) return false;
            pipeline.Downscale();
            return true;
        }

        public int FrameByteCount => pipeline.OutputByteCount;
        public int OutputWidth => pipeline.OutputWidth;
        public int OutputHeight => pipeline.OutputHeight;

        /// <summary>RGBA frame for ffmpeg (call after Step).</summary>
        public void ReadFrame(IntPtr destination) => pipeline.ReadFrame(destination);

        /// <summary>Draw the current frame into the bound framebuffer (the screen).</summary>
        public void Present(int targetWidth, int targetHeight) => pipeline.Present(targetWidth, targetHeight);

        public void SkipForward(int ms) => playback.SkipForward(ms);

        public void Dispose()
        {
            if (disposed) return;
            disposed = true;
            Settings.running = false;
            playback.Dispose();
            try { renderer.Dispose(); } catch (Exception e) { Console.WriteLine(e); }
            try { pipeline.Dispose(); } catch (Exception e) { Console.WriteLine(e); }
            midi.Reset();
        }
    }
}
