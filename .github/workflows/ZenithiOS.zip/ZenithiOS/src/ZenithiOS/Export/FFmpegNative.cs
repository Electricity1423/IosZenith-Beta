using System;
using System.Runtime.InteropServices;
using System.Text;

namespace Zenith.iOS.Export
{
    /// <summary>
    /// Bindings to ffmpeg-ios/src/zenith_ffmpeg.[ch] (ffmpeg's command line tool linked into the app).
    /// The library is statically linked, hence "__Internal".
    /// </summary>
    internal static class FFmpegNative
    {
        const string Lib = "__Internal";

        [DllImport(Lib)] static extern IntPtr zenith_ffmpeg_version();
        [DllImport(Lib)] static extern int zenith_ffmpeg_start(int argc, IntPtr[] argv);
        [DllImport(Lib)] static extern int zenith_ffmpeg_wait();
        [DllImport(Lib)] static extern int zenith_ffmpeg_is_running();
        [DllImport(Lib)] static extern void zenith_ffmpeg_cancel();
        [DllImport(Lib)] static extern int zenith_ffmpeg_read_log(byte[] buf, int size);
        [DllImport(Lib)] static extern void zenith_ffmpeg_set_log_level(int level);
        [DllImport(Lib)] static extern int zenith_ffmpeg_make_fifo(IntPtr path);
        [DllImport(Lib)] static extern int zenith_ffmpeg_open_fifo_writer(IntPtr path, int timeoutMs);
        [DllImport(Lib)] static extern int zenith_ffmpeg_write_fully(int fd, IntPtr data, UIntPtr len);
        [DllImport(Lib)] static extern void zenith_ffmpeg_close_fd(int fd);

        public const int LogInfo = 32, LogWarning = 24, LogError = 16;

        public static string Version => Marshal.PtrToStringAnsi(zenith_ffmpeg_version());

        public static bool IsRunning => zenith_ffmpeg_is_running() != 0;
        public static void Cancel() => zenith_ffmpeg_cancel();
        public static void SetLogLevel(int level) => zenith_ffmpeg_set_log_level(level);
        public static int Wait() => zenith_ffmpeg_wait();
        public static void CloseFd(int fd) => zenith_ffmpeg_close_fd(fd);

        /// <summary>Starts "ffmpeg args..." on its own thread.  Returns false if one is already running.</summary>
        public static bool Start(params string[] args)
        {
            var all = new string[args.Length + 1];
            all[0] = "ffmpeg";
            Array.Copy(args, 0, all, 1, args.Length);

            var ptrs = new IntPtr[all.Length];
            try
            {
                for (int i = 0; i < all.Length; i++) ptrs[i] = Marshal.StringToCoTaskMemUTF8(all[i]);
                return zenith_ffmpeg_start(all.Length, ptrs) == 0;   // arguments are copied by the native side
            }
            finally
            {
                foreach (var p in ptrs) if (p != IntPtr.Zero) Marshal.FreeCoTaskMem(p);
            }
        }

        public static bool MakeFifo(string path)
        {
            IntPtr p = Marshal.StringToCoTaskMemUTF8(path);
            try { return zenith_ffmpeg_make_fifo(p) == 0; }
            finally { Marshal.FreeCoTaskMem(p); }
        }

        /// <summary>Returns a file descriptor, or -1 if ffmpeg stopped (or the timeout passed) before opening the pipe.</summary>
        public static int OpenFifoWriter(string path, int timeoutMs)
        {
            IntPtr p = Marshal.StringToCoTaskMemUTF8(path);
            try { return zenith_ffmpeg_open_fifo_writer(p, timeoutMs); }
            finally { Marshal.FreeCoTaskMem(p); }
        }

        public static bool WriteFully(int fd, IntPtr data, int length)
        {
            return zenith_ffmpeg_write_fully(fd, data, (UIntPtr)(uint)length) == 0;
        }

        /// <summary>Text ffmpeg has logged since the last call.</summary>
        public static string ReadLog()
        {
            var sb = new StringBuilder();
            var buf = new byte[8192];
            int n;
            while ((n = zenith_ffmpeg_read_log(buf, buf.Length)) > 0)
                sb.Append(Encoding.UTF8.GetString(buf, 0, n));
            return sb.ToString();
        }
    }
}
