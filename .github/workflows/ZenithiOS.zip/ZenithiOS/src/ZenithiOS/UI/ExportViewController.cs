using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using Foundation;
using UIKit;
using UniformTypeIdentifiers;
using Zenith.iOS.Export;

namespace Zenith.iOS.UI
{
    internal sealed class ExportViewController : FormViewController
    {
        static readonly int[][] Resolutions = { new[] { 1280, 720 }, new[] { 1920, 1080 }, new[] { 2560, 1440 }, new[] { 3840, 2160 } };
        static readonly int[] FpsValues = { 30, 60 };

        AppSettings S => SettingsStore.Current;
        string audioPath;
        UILabel audioLabel, statusLabel;
        UIProgressView progress;
        UIButton startBtn, cancelBtn;
        VideoExporter running;
        bool busy;

        public ExportViewController() { Title = "Export video"; }

        protected override void Build()
        {
            AddHeader("Video");
            AddSegmented("Resolution", new[] { "720p", "1080p", "1440p", "4K" }, S.ResolutionIndex, v => S.ResolutionIndex = v);
            AddSegmented("Anti-aliasing (renders at 2x then downsamples)", new[] { "Off", "2x SSAA" }, S.SsaaIndex, v => S.SsaaIndex = v);
            AddSegmented("Frame rate", new[] { "30", "60" }, S.FpsIndex, v => S.FpsIndex = v);
            AddSwitch("HEVC (H.265) instead of H.264", S.Hevc, v => S.Hevc = v);
            AddSwitch("Fixed bitrate (off = quality target)", S.UseBitrate, v => S.UseBitrate = v);
            AddSlider("Bitrate (Mbit/s)", 2, 100, S.BitrateMbps, "0", v => S.BitrateMbps = (int)Math.Round(v));
            AddSlider("Quality when not using bitrate (lower = better)", 0, 40, S.Quality, "0", v => S.Quality = (int)Math.Round(v));
            AddSwitch("Also write a transparency-mask video", S.Mask, v => S.Mask = v);

            AddHeader("Audio");
            audioLabel = new UILabel { Text = "No audio (video only)", TextColor = UIColor.SecondaryLabel, Lines = 0 };
            Stack.AddArrangedSubview(audioLabel);
            AddButton("Choose audio file…", PickAudio);
            AddButton("Remove audio", () => { audioPath = null; audioLabel.Text = "No audio (video only)"; });

            AddHeader("Export");
            progress = new UIProgressView(UIProgressViewStyle.Default);
            Stack.AddArrangedSubview(progress);
            statusLabel = new UILabel { Text = "Ready", Lines = 0, Font = UIFont.MonospacedDigitSystemFontOfSize(14, UIFontWeight.Regular) };
            Stack.AddArrangedSubview(statusLabel);
            startBtn = AddButton("Start export", Start, true);
            cancelBtn = AddButton("Cancel", () => { if (running != null) { running.CancelRequested = true; statusLabel.Text = "Cancelling…"; } });
            cancelBtn.Enabled = false;
            AddNote("Keep the app open and the screen on: iOS does not allow graphics work in the background, so " +
                    "locking the phone pauses the export until you come back.");
        }

        public override void ViewWillDisappear(bool animated)
        {
            base.ViewWillDisappear(animated);
            SettingsStore.Save();
        }

        void PickAudio()
        {
            var picker = new UIDocumentPickerViewController(new[] { UTType.Audio }, true);
            picker.Delegate = new AudioPickerDelegate(url =>
            {
                try
                {
                    string dest = Path.Combine(Path.GetTempPath(), "zenith_audio" + Path.GetExtension(url.Path));
                    File.Copy(url.Path, dest, true);
                    audioPath = dest;
                    audioLabel.Text = url.LastPathComponent;
                }
                catch (Exception ex) { Alert("Couldn't use that file", ex.Message); }
            });
            PresentViewController(picker, true, null);
        }

        void Start()
        {
            var midi = AppState.Midi;
            if (midi == null || busy) return;
            busy = true;
            startBtn.Enabled = false; cancelBtn.Enabled = true;
            progress.Progress = 0;
            UIApplication.SharedApplication.IdleTimerDisabled = true;

            string docs = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            string stem = Path.GetFileNameWithoutExtension(AppState.MidiName ?? "zenith") + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss");
            string ext = ".mp4";
            var res = Resolutions[S.ResolutionIndex];
            var o = new ExportOptions
            {
                OutputPath = Path.Combine(docs, stem + ext),
                MaskOutputPath = S.Mask ? Path.Combine(docs, stem + "_mask" + ext) : null,
                AudioPath = audioPath,
                Width = res[0], Height = res[1],
                Ssaa = S.SsaaIndex == 1 ? 2 : 1,
                Fps = FpsValues[S.FpsIndex],
                UseBitrate = S.UseBitrate,
                BitrateKbps = S.BitrateMbps * 1000,
                Crf = S.Quality,
                Hevc = S.Hevc,
            };
            var trail = S.Trail.Clone();
            var exporter = new VideoExporter();
            running = exporter;
            exporter.ProgressChanged += (p, fps) => InvokeOnMainThread(() =>
            {
                progress.Progress = (float)p;
                statusLabel.Text = $"{p * 100:0.0}% · {fps:0.0} frames/s";
            });
            statusLabel.Text = "Starting…";

            var thread = new Thread(() =>
            {
                ExportResult r;
                try { r = exporter.Run(midi, o, trail, AppState.Aura); }
                catch (Exception ex) { r = new ExportResult { Success = false, Message = ex.Message }; }
                InvokeOnMainThread(() => Finished(r, o));
            }, 16 * 1024 * 1024) { IsBackground = false, Name = "Zenith export" };
            thread.Start();
        }

        void Finished(ExportResult r, ExportOptions o)
        {
            busy = false; running = null;
            startBtn.Enabled = true; cancelBtn.Enabled = false;
            UIApplication.SharedApplication.IdleTimerDisabled = false;
            statusLabel.Text = r.Message ?? (r.Success ? "Done" : "Failed");
            if (r.Success)
            {
                var items = new List<NSObject> { NSUrl.FromFilename(o.OutputPath) };
                if (o.MaskOutputPath != null && File.Exists(o.MaskOutputPath)) items.Add(NSUrl.FromFilename(o.MaskOutputPath));
                var share = new UIActivityViewController(items.ToArray(), null);
                if (share.PopoverPresentationController != null) share.PopoverPresentationController.SourceView = startBtn;
                PresentViewController(share, true, null);
            }
            else if (!string.IsNullOrEmpty(r.FfmpegLog))
            {
                var log = r.FfmpegLog.Length > 1500 ? r.FfmpegLog.Substring(r.FfmpegLog.Length - 1500) : r.FfmpegLog;
                Alert("Export failed", r.Message + "\n\n" + log);
            }
        }
    }
}
