using System;

namespace ZenithEngine
{
    /// <summary>
    /// Drop-in replacement for the parts of OpenTK.Graphics.Color4 that Zenith uses.
    /// NOTE: like OpenTK, passing four int literals picks the byte constructor
    /// (0..255).  Use float literals (1f) for 0..1 colours.
    /// </summary>
    public struct Color4
    {
        public float R, G, B, A;

        public Color4(float r, float g, float b, float a)
        {
            R = r; G = g; B = b; A = a;
        }

        public Color4(byte r, byte g, byte b, byte a)
        {
            R = r / 255f; G = g / 255f; B = b / 255f; A = a / 255f;
        }

        public static Color4 Transparent => new Color4(0f, 0f, 0f, 0f);
        public static Color4 Black => new Color4(0f, 0f, 0f, 1f);
        public static Color4 White => new Color4(1f, 1f, 1f, 1f);
        public static Color4 Gray => new Color4((byte)128, (byte)128, (byte)128, (byte)255);

        static float Clamp01(float v) => v < 0f ? 0f : (v > 1f ? 1f : v);

        /// <summary>Same maths as OpenTK 3.1 Color4.FromHsv (all inputs 0..1).</summary>
        public static Color4 FromHsv(float h, float s, float v, float a)
        {
            float hue = Clamp01(h) * 360f;
            float sat = Clamp01(s);
            float bri = Clamp01(v);
            float alpha = Clamp01(a);

            float chroma = bri * sat;
            float hue1 = hue / 60f;
            float x = chroma * (1f - Math.Abs((hue1 % 2f) - 1f));

            float r = 0, g = 0, b = 0;
            switch ((int)hue1)
            {
                case 0: r = chroma; g = x; break;
                case 1: r = x; g = chroma; break;
                case 2: g = chroma; b = x; break;
                case 3: g = x; b = chroma; break;
                case 4: r = x; b = chroma; break;
                default: r = chroma; b = x; break;
            }
            float m = bri - chroma;
            return new Color4(r + m, g + m, b + m, alpha);
        }
    }
}
