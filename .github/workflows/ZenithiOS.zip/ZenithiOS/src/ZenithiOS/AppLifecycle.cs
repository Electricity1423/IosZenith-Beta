using System.Threading;

namespace Zenith.iOS
{
    /// <summary>
    /// iOS forbids OpenGL work while the app is not active.  The exporter waits on this between
    /// frames, so locking the phone or switching apps pauses an export instead of killing it.
    /// </summary>
    internal static class AppLifecycle
    {
        public static readonly ManualResetEventSlim Active = new ManualResetEventSlim(true);
        public static void SetActive(bool active)
        {
            if (active) Active.Set(); else Active.Reset();
        }
    }
}
