using Foundation;
using UIKit;
using Zenith.iOS.UI;

namespace Zenith.iOS
{
    [Register("AppDelegate")]
    public class AppDelegate : UIApplicationDelegate
    {
        public override UIWindow Window { get; set; }

        HomeViewController home;

        public override bool FinishedLaunching(UIApplication application, NSDictionary launchOptions)
        {
            Window = new UIWindow(UIScreen.MainScreen.Bounds);
            home = new HomeViewController();
            Window.RootViewController = new UINavigationController(home);
            Window.MakeKeyAndVisible();
            return true;
        }

        // Opening a .mid from the Files app / share sheet.
        public override bool OpenUrl(UIApplication app, NSUrl url, NSDictionary options)
        {
            home?.LoadFromExternalUrl(url);
            return true;
        }

        // OpenGL ES must not be used while the app is inactive; the exporter waits on this flag.
        public override void OnResignActivation(UIApplication application) => AppLifecycle.SetActive(false);
        public override void OnActivated(UIApplication application) => AppLifecycle.SetActive(true);
        public override void DidEnterBackground(UIApplication application) => AppLifecycle.SetActive(false);
        public override void WillEnterForeground(UIApplication application) { }
    }
}
