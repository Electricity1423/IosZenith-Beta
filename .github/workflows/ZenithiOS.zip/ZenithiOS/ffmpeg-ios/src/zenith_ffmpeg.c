/* See zenith_ffmpeg.h */
#include "zenith_ffmpeg.h"

#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <signal.h>
#include <stdarg.h>
#include <stdatomic.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

#include "libavutil/avutil.h"
#include "libavutil/log.h"
#include "libavcodec/avcodec.h"

/* Provided by the patched fftools/ffmpeg.c */
extern int  zenith_ffmpeg_main(int argc, char **argv);
extern void zenith_ffmpeg_request_stop(void);

/* ---- log capture --------------------------------------------------------- */

#define LOG_CAP (64 * 1024)

static pthread_mutex_t log_lock = PTHREAD_MUTEX_INITIALIZER;
static char   log_buf[LOG_CAP];
static size_t log_len = 0;
static int    log_print_prefix = 1;

static void log_append(const char *s, size_t n)
{
    if (n >= LOG_CAP) {            /* keep only the tail */
        s += n - (LOG_CAP - 1);
        n = LOG_CAP - 1;
    }
    if (log_len + n > LOG_CAP - 1) {   /* drop oldest text */
        size_t drop = log_len + n - (LOG_CAP - 1);
        memmove(log_buf, log_buf + drop, log_len - drop);
        log_len -= drop;
    }
    memcpy(log_buf + log_len, s, n);
    log_len += n;
}

static void zenith_log_callback(void *avcl, int level, const char *fmt, va_list vl)
{
    char line[2048];
    if (level > av_log_get_level())
        return;
    pthread_mutex_lock(&log_lock);
    av_log_format_line(avcl, level, fmt, vl, line, sizeof(line), &log_print_prefix);
    log_append(line, strlen(line));
    pthread_mutex_unlock(&log_lock);
}

int zenith_ffmpeg_read_log(char *buf, int size)
{
    int n;
    if (!buf || size <= 0)
        return 0;
    pthread_mutex_lock(&log_lock);
    n = (int)log_len;
    if (n > size - 1)
        n = size - 1;
    memcpy(buf, log_buf, n);
    buf[n] = 0;
    memmove(log_buf, log_buf + n, log_len - n);
    log_len -= n;
    pthread_mutex_unlock(&log_lock);
    return n;
}

void zenith_ffmpeg_set_log_level(int level)
{
    av_log_set_level(level);
}

const char *zenith_ffmpeg_version(void)
{
    return av_version_info();
}

/* ---- running ffmpeg ------------------------------------------------------ */

static pthread_mutex_t run_lock = PTHREAD_MUTEX_INITIALIZER;   /* guards state below */
static atomic_int running = 0;
static int        have_thread = 0;
static pthread_t  thread;
static int        thread_result = 0;

typedef struct RunArgs {
    int    argc;
    char **argv;
} RunArgs;

static int run_main(int argc, char **argv)
{
    int ret;
    signal(SIGPIPE, SIG_IGN);
    av_log_set_callback(zenith_log_callback);
    ret = zenith_ffmpeg_main(argc, argv);
    return ret;
}

static void *thread_main(void *p)
{
    RunArgs *a = p;
    int ret = run_main(a->argc, a->argv);
    for (int i = 0; i < a->argc; i++)
        free(a->argv[i]);
    free(a->argv);
    free(a);
    thread_result = ret;
    atomic_store(&running, 0);
    return NULL;
}

int zenith_ffmpeg_start(int argc, char **argv)
{
    RunArgs *a;
    pthread_attr_t attr;
    int rc;

    pthread_mutex_lock(&run_lock);
    if (atomic_load(&running) || have_thread) {
        pthread_mutex_unlock(&run_lock);
        return -1;
    }
    a = calloc(1, sizeof(*a));
    if (!a) { pthread_mutex_unlock(&run_lock); return -1; }
    a->argc = argc;
    a->argv = calloc(argc + 1, sizeof(char *));
    if (!a->argv) { free(a); pthread_mutex_unlock(&run_lock); return -1; }
    for (int i = 0; i < argc; i++)
        a->argv[i] = strdup(argv[i]);

    atomic_store(&running, 1);
    pthread_attr_init(&attr);
    pthread_attr_setstacksize(&attr, 8 * 1024 * 1024);
    rc = pthread_create(&thread, &attr, thread_main, a);
    pthread_attr_destroy(&attr);
    if (rc != 0) {
        atomic_store(&running, 0);
        for (int i = 0; i < argc; i++) free(a->argv[i]);
        free(a->argv);
        free(a);
        pthread_mutex_unlock(&run_lock);
        return -1;
    }
    have_thread = 1;
    pthread_mutex_unlock(&run_lock);
    return 0;
}

int zenith_ffmpeg_wait(void)
{
    pthread_t t;
    pthread_mutex_lock(&run_lock);
    if (!have_thread) {
        pthread_mutex_unlock(&run_lock);
        return thread_result;
    }
    t = thread;
    pthread_mutex_unlock(&run_lock);

    pthread_join(t, NULL);

    pthread_mutex_lock(&run_lock);
    have_thread = 0;
    pthread_mutex_unlock(&run_lock);
    return thread_result;
}

int zenith_ffmpeg_execute(int argc, char **argv)
{
    if (zenith_ffmpeg_start(argc, argv) != 0)
        return -1;
    return zenith_ffmpeg_wait();
}

int zenith_ffmpeg_is_running(void)
{
    return atomic_load(&running);
}

void zenith_ffmpeg_cancel(void)
{
    if (atomic_load(&running))
        zenith_ffmpeg_request_stop();
}

/* ---- FIFO helpers -------------------------------------------------------- */

int zenith_ffmpeg_make_fifo(const char *path)
{
    unlink(path);
    return mkfifo(path, 0600);
}

static void sleep_ms(int ms)
{
    struct timespec ts = { ms / 1000, (ms % 1000) * 1000000L };
    nanosleep(&ts, NULL);
}

int zenith_ffmpeg_open_fifo_writer(const char *path, int timeout_ms)
{
    int waited = 0;
    signal(SIGPIPE, SIG_IGN);
    for (;;) {
        /* O_NONBLOCK makes open(O_WRONLY) fail with ENXIO until a reader exists */
        int fd = open(path, O_WRONLY | O_NONBLOCK);
        if (fd >= 0) {
            int fl = fcntl(fd, F_GETFL);
            fcntl(fd, F_SETFL, fl & ~O_NONBLOCK);   /* blocking writes = back-pressure */
            return fd;
        }
        if (errno != ENXIO && errno != EINTR)
            return -1;
        if (!atomic_load(&running))
            return -1;                               /* ffmpeg already gave up */
        if (timeout_ms >= 0 && waited >= timeout_ms)
            return -1;
        sleep_ms(5);
        waited += 5;
    }
}

int zenith_ffmpeg_write_fully(int fd, const void *data, size_t len)
{
    const unsigned char *p = data;
    while (len > 0) {
        ssize_t n = write(fd, p, len);
        if (n < 0) {
            if (errno == EINTR)
                continue;
            return -1;                               /* EPIPE: ffmpeg is gone */
        }
        p   += n;
        len -= (size_t)n;
    }
    return 0;
}

void zenith_ffmpeg_close_fd(int fd)
{
    if (fd >= 0)
        close(fd);
}
