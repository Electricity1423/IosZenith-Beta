using CoreGraphics;
using Foundation;
using UIKit;

namespace Zenith.iOS.Render
{
    /// <summary>The glow image drawn behind pressed keys, decoded to RGBA bytes for OpenGL.</summary>
    internal sealed class AuraImage
    {
        public byte[] Rgba { get; private set; }
        public int Width { get; private set; }
        public int Height { get; private set; }

        public static AuraImage LoadBundled(string name = "aura_ring")
        {
            string path = NSBundle.MainBundle.PathForResource(name, "png");
            if (path == null) return null;
            return FromImage(UIImage.FromFile(path));
        }

        public static AuraImage FromImage(UIImage image)
        {
            if (image?.CGImage == null) return null;
            var cg = image.CGImage;
            int w = (int)cg.Width;
            int h = (int)cg.Height;
            var data = new byte[w * h * 4];
            using (var cs = CGColorSpace.CreateDeviceRGB())
            using (var ctx = new CGBitmapContext(data, w, h, 8, w * 4, cs, CGImageAlphaInfo.PremultipliedLast))
            {
                // Core Graphics' origin is bottom-left; the image is symmetrical, but keep it upright anyway.
                ctx.TranslateCTM(0, h);
                ctx.ScaleCTM(1, -1);
                ctx.DrawImage(new CGRect(0, 0, w, h), cg);
            }
            return new AuraImage { Rgba = data, Width = w, Height = h };
        }
    }
}
