using ZenithEngine;
using Zenith.iOS.Render;

namespace Zenith.iOS.UI
{
    /// <summary>The MIDI currently loaded, shared between screens.</summary>
    internal static class AppState
    {
        public static MidiFile Midi;
        public static string MidiName;
        static AuraImage aura;
        static bool auraTried;

        public static AuraImage Aura
        {
            get
            {
                if (!auraTried) { auraTried = true; aura = AuraImage.LoadBundled("aura_ring"); }
                return aura;
            }
        }
    }
}
