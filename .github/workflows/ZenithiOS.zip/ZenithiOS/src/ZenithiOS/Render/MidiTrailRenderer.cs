using System;
using Zenith.iOS.GL;
using ZenithEngine;

namespace Zenith.iOS.Render
{
    /// <summary>
    /// MIDITrail+ for iOS: a port of Zenith's MidiTrailRender/Render.cs to OpenGL ES 3.0.
    ///
    /// What changed from the desktop plugin (everything else is the same code and the same numbers):
    ///   * GLSL 3.30 -> GLSL ES 3.00 (explicit float literals, precision qualifiers)
    ///   * GL_QUADS -> GL_TRIANGLES (index buffers made by Gl.MakeQuadIndices)
    ///   * double vertex attributes -> float
    ///   * no fixed-function state (EnableClientState / Texture2D / VertexPointer)
    ///   * OpenTK Matrix4 / Color4 -> ZenithEngine.Matrix4 / Color4 (same conventions)
    ///   * WPF settings panel -> MidiTrailSettings, edited by the iOS settings screen
    ///   * aura image arrives as RGBA bytes (set by the app) instead of a System.Drawing bitmap
    /// </summary>
    internal sealed class MidiTrailRenderer : IMidiRenderer
    {
        public string Name => "MIDITrail+";

        public bool Initialized { get; private set; } = false;

        #region Shaders
        const string WhiteKeyVert = @"#version 300 es
layout(location=0) in vec3 in_position;
layout(location=1) in float in_brightness;
layout(location=2) in float blend_fac;

out vec4 v2f_color;

uniform mat4 MVP;
uniform vec4 coll;
uniform vec4 colr;

void main()
{
    gl_Position = MVP * vec4(in_position, 1.0);
    v2f_color = vec4((coll.xyz * blend_fac + colr.xyz * (1.0 - blend_fac)) * in_brightness, 1.0);
}
";
        const string FlatFrag = @"#version 300 es
precision highp float;
in vec4 v2f_color;
layout (location=0) out vec4 out_color;

void main()
{
    out_color = v2f_color;
}
";
        const string BlackKeyVert = @"#version 300 es
layout(location=0) in vec3 in_position;
layout(location=1) in float in_brightness;
layout(location=2) in float blend_fac;

out vec4 v2f_color;

uniform mat4 MVP;
uniform vec4 coll;
uniform vec4 colr;

void main()
{
    gl_Position = MVP * vec4(in_position, 1.0);
    v2f_color = vec4(vec3(1.0 - in_brightness) + (coll.xyz * blend_fac + colr.xyz * (1.0 - blend_fac)) * in_brightness, 1.0);
}
";
        const string NoteVert = @"#version 300 es
layout(location=0) in vec3 in_position;
layout(location=1) in vec4 in_color;
layout(location=2) in float in_shade;

out vec4 v2f_color;

uniform mat4 MVP;

void main()
{
    gl_Position = MVP * vec4(in_position, 1.0);
    v2f_color = vec4(in_color.xyz + vec3(in_shade), in_color.w);
}
";
        const string CircleVert = @"#version 300 es
layout(location=0) in vec3 in_position;
layout(location=1) in vec4 in_color;
layout(location=2) in vec2 in_uv;

out vec4 v2f_color;
out vec2 uv;

uniform mat4 MVP;

void main()
{
    gl_Position = MVP * vec4(in_position, 1.0);
    v2f_color = in_color;
    uv = in_uv;
}
";
        const string CircleFrag = @"#version 300 es
precision highp float;
in vec4 v2f_color;
in vec2 uv;

uniform sampler2D textureSampler;

layout (location=0) out vec4 out_color;

void main()
{
    out_color = v2f_color;
    out_color.w *= texture(textureSampler, uv).w;
}
";
        #endregion

        int whiteKeyShader, blackKeyShader, noteShader, circleShader, copyShader;
        int uWhiteKeyMVP, uWhiteKeycoll, uWhiteKeycolr;
        int uBlackKeyMVP, uBlackKeycoll, uBlackKeycolr;
        int uNoteMVP, uCircleMVP;

        public bool ManualNoteDelete => false;
        public double Tempo { get; set; }
        public MidiInfo CurrentMidi { get; set; }
        public double NoteScreenTime => settings.viewdist * settings.deltaTimeOnScreen;
        public NoteColor[][] NoteColors { get; set; }
        public long LastNoteCount { get; private set; }

        public double NoteCollectorOffset
        {
            get
            {
                if (settings.eatNotes) return 0;
                return -settings.deltaTimeOnScreen * settings.viewback;
            }
        }

        bool[] blackKeys = new bool[257];
        int[] keynum = new int[257];

        readonly RenderSettings renderSettings;
        readonly MidiTrailSettings settings;

        /// <summary>Live settings: the app's settings screen edits this object while rendering.</summary>
        public MidiTrailSettings Settings => settings;

        /// <summary>RGBA pixels of the aura (glow) image; bump AuraVersion after changing.</summary>
        public byte[] AuraRgba;
        public int AuraWidth, AuraHeight;
        public long AuraVersion = 1;
        long uploadedAuraVersion;

        PostBuffer3D buffer3d;
        ScreenQuad screenQuad;

        int[] whiteKeyVert = new int[7 * 3];
        int whiteKeyCol, whiteKeyIndx, whiteKeyBlend;
        int blackKeyVert, blackKeyCol, blackKeyIndx, blackKeyBlend;
        int noteVert, noteCol, noteIndx, noteShade;

        const int noteBuffLen = 2048 * 64;   // quads per flush (desktop: 2048*256; smaller to suit phones)

        float[] noteVertBuff;
        float[] noteColBuff;
        float[] noteShadeBuff;
        int noteBuffPos = 0;

        int circleVert, circleColor, circleUV, circleIndx;
        float[] circleVertBuff;
        float[] circleColorBuff;
        float[] circleUVBuff;
        int circleBuffPos = 0;

        int auraTex;

        int whiteKeyIndexCount = 0;
        int blackKeyIndexCount = 0;

        public MidiTrailRenderer(RenderSettings renderSettings, MidiTrailSettings settings)
        {
            this.renderSettings = renderSettings;
            this.settings = settings;
            for (int i = 0; i < blackKeys.Length; i++) blackKeys[i] = isBlackNote(i);
            int b = 0;
            int w = 0;
            for (int i = 0; i < keynum.Length; i++)
            {
                if (blackKeys[i]) keynum[i] = b++;
                else keynum[i] = w++;
            }
        }

        void ReloadAuraTexture()
        {
            Gl.glBindTexture(Gl.TEXTURE_2D, auraTex);
            if (AuraRgba != null && AuraWidth > 0 && AuraHeight > 0)
            {
                Gl.TexImage2DRgba(AuraWidth, AuraHeight, AuraRgba);
            }
            else
            {
                // no image: a single opaque white pixel (aura becomes a flat square)
                Gl.TexImage2DRgba(1, 1, new byte[] { 255, 255, 255, 255 });
            }
            Gl.glTexParameteri(Gl.TEXTURE_2D, Gl.TEXTURE_MIN_FILTER, Gl.LINEAR);
            Gl.glTexParameteri(Gl.TEXTURE_2D, Gl.TEXTURE_MAG_FILTER, Gl.LINEAR);
            Gl.glTexParameteri(Gl.TEXTURE_2D, Gl.TEXTURE_WRAP_S, Gl.CLAMP_TO_EDGE);
            Gl.glTexParameteri(Gl.TEXTURE_2D, Gl.TEXTURE_WRAP_T, Gl.CLAMP_TO_EDGE);
            uploadedAuraVersion = AuraVersion;
        }

        public void Dispose()
        {
            if (!Initialized) return;
            uploadedAuraVersion = 0;
            Gl.DeleteTexture(auraTex);
            buffer3d.Dispose();
            screenQuad.Dispose();

            foreach (int b in whiteKeyVert) Gl.DeleteBuffer(b);
            foreach (int b in new[] {
                whiteKeyCol, blackKeyVert, blackKeyCol,
                whiteKeyIndx, blackKeyIndx, whiteKeyBlend, blackKeyBlend,
                noteVert, noteCol, noteIndx, noteShade,
                circleVert, circleColor, circleUV, circleIndx })
                Gl.DeleteBuffer(b);

            Gl.glDeleteProgram(whiteKeyShader);
            Gl.glDeleteProgram(blackKeyShader);
            Gl.glDeleteProgram(noteShader);
            Gl.glDeleteProgram(circleShader);
            Gl.glDeleteProgram(copyShader);

            noteVertBuff = null;
            noteColBuff = null;
            noteShadeBuff = null;
            circleVertBuff = null;
            circleColorBuff = null;
            circleUVBuff = null;

            Initialized = false;
            Console.WriteLine("Disposed of MIDITrailRenderer");
        }

        static void Upload(int target, int buffer, float[] data, int usage)
        {
            Gl.glBindBuffer(target, buffer);
            Gl.BufferData(target, data, data.Length, usage);
        }

        static void UploadIndices(int buffer, int[] data)
        {
            Gl.glBindBuffer(Gl.ELEMENT_ARRAY_BUFFER, buffer);
            Gl.BufferData(Gl.ELEMENT_ARRAY_BUFFER, data, data.Length, Gl.STATIC_DRAW);
        }

        static float[] ToFloat(double[] d)
        {
            var f = new float[d.Length];
            for (int i = 0; i < d.Length; i++) f[i] = (float)d[i];
            return f;
        }

        public void Init()
        {
            whiteKeyShader = Gl.MakeProgram(WhiteKeyVert, FlatFrag);
            blackKeyShader = Gl.MakeProgram(BlackKeyVert, FlatFrag);
            noteShader = Gl.MakeProgram(NoteVert, FlatFrag);
            circleShader = Gl.MakeProgram(CircleVert, CircleFrag);
            copyShader = Gl.MakeProgram(PostPipeline.CopyVertexShader, PostPipeline.CopyFragmentShader);

            uWhiteKeyMVP = Gl.GetUniformLocation(whiteKeyShader, "MVP");
            uWhiteKeycoll = Gl.GetUniformLocation(whiteKeyShader, "coll");
            uWhiteKeycolr = Gl.GetUniformLocation(whiteKeyShader, "colr");

            uBlackKeyMVP = Gl.GetUniformLocation(blackKeyShader, "MVP");
            uBlackKeycoll = Gl.GetUniformLocation(blackKeyShader, "coll");
            uBlackKeycolr = Gl.GetUniformLocation(blackKeyShader, "colr");

            uNoteMVP = Gl.GetUniformLocation(noteShader, "MVP");
            uCircleMVP = Gl.GetUniformLocation(circleShader, "MVP");

            buffer3d = new PostBuffer3D(renderSettings.width, renderSettings.height);
            screenQuad = new ScreenQuad();

            for (int i = 0; i < whiteKeyVert.Length; i++) whiteKeyVert[i] = Gl.GenBuffer();
            whiteKeyCol = Gl.GenBuffer();
            whiteKeyIndx = Gl.GenBuffer();
            whiteKeyBlend = Gl.GenBuffer();

            blackKeyVert = Gl.GenBuffer();
            blackKeyCol = Gl.GenBuffer();
            blackKeyIndx = Gl.GenBuffer();
            blackKeyBlend = Gl.GenBuffer();

            noteVert = Gl.GenBuffer();
            noteCol = Gl.GenBuffer();
            noteIndx = Gl.GenBuffer();
            noteShade = Gl.GenBuffer();

            circleVert = Gl.GenBuffer();
            circleColor = Gl.GenBuffer();
            circleUV = Gl.GenBuffer();
            circleIndx = Gl.GenBuffer();

            noteVertBuff = new float[noteBuffLen * 4 * 3];
            noteColBuff = new float[noteBuffLen * 4 * 4];
            noteShadeBuff = new float[noteBuffLen * 4];

            circleVertBuff = new float[256 * 4 * 3];
            circleColorBuff = new float[256 * 4 * 4];
            circleUVBuff = new float[256 * 4 * 2];

            UploadIndices(noteIndx, Gl.MakeQuadIndices(noteBuffLen));
            UploadIndices(circleIndx, Gl.MakeQuadIndices(256));

            auraTex = Gl.GenTexture();
            ReloadAuraTexture();

            float whitekeylen = 5.0f;
            float blackkeylen = 6.9f;
            float lenfac = 0.69f;
            float blackKeyEnd = whitekeylen * lenfac;
            float left = 0.3f;
            float right = 0.7f;

            #region White Key Model

            double[] verts = new double[] {
                //front
                0, 0, -whitekeylen,//0
                0, 0.7, -whitekeylen,
                1, 0.7, -whitekeylen,
                1, 0, -whitekeylen,
                //front dark
                0, 0.7, -whitekeylen,//12
                0, 1, -whitekeylen,
                1, 1, -whitekeylen,
                1, 0.7, -whitekeylen,
                //top
                1, 1, -blackKeyEnd,//24
                1, 1, -whitekeylen,
                0, 1, -whitekeylen,
                0, 1, -blackKeyEnd,
                //notch
                0, 1, -whitekeylen,
                0.03, 0.95, -whitekeylen - 0.1,//36
                0.97, 0.95, -whitekeylen - 0.1,
                1, 1, -whitekeylen,

                0, 0.90, -whitekeylen - 0.07,//48
                0.03, 0.95, -whitekeylen - 0.1,
                0.97, 0.95, -whitekeylen - 0.1,
                1, 0.90, -whitekeylen - 0.07,
                //left
                0, 1, -blackKeyEnd,//60
                0, 1, -whitekeylen,
                0, 0, -whitekeylen,
                0, 0, -blackKeyEnd,
                //right
                1, 1, -blackKeyEnd,//72
                1, 1, -whitekeylen,
                1, 0, -whitekeylen,
                1, 0, -blackKeyEnd,
                //back
                left, 0, 0,//84
                left, 1, 0,
                right, 1, 0,
                right, 0, 0,

                //left2
                left, 1, 0,//96
                left, 1, -blackKeyEnd,
                left, 0, -blackKeyEnd,
                left, 0, 0,
                //right2
                right, 1, 0,//108
                right, 1, -blackKeyEnd,
                right, 0, -blackKeyEnd,
                right, 0, 0,
                //top
                left, 1, 0,//120
                left, 1, -blackKeyEnd,
                right, 1, -blackKeyEnd,
                right, 1, 0,
                //left inner
                0, 1, -blackKeyEnd,//96
                left, 1, -blackKeyEnd,
                left, 0, -blackKeyEnd,
                0, 0, -blackKeyEnd,
                //right inner
                1, 1, -blackKeyEnd,//108
                right, 1, -blackKeyEnd,
                right, 0, -blackKeyEnd,
                1, 0, -blackKeyEnd,
            };
            int[] rightIndxs = new int[] {
                7 * 12 + 6, 7 * 12 + 9,
                9 * 12, 9 * 12 + 3, 9 * 12 + 6, 9 * 12 + 9,
                10 * 12 + 6, 10 * 12 + 9,
                12 * 12 + 3, 12 * 12 + 6,
            };
            int[] leftIndxs = new int[] {
                7 * 12, 7 * 12 + 3,
                8 * 12, 8 * 12 + 3, 8 * 12 + 6, 8 * 12 + 9,
                10 * 12, 10 * 12 + 3,
                11 * 12 + 3, 11 * 12 + 6,
            };

            float[] cols = new float[] {
                //front
                0.7f, 0.8f, 0.8f, 0.7f,
                //front dark
                0.6f, 0.6f, 0.6f, 0.6f,
                //top
                1, 1, 1, 1,
                //notch
                1f, 0.9f, 0.9f, 1f,

                0.9f, 0.9f, 0.9f, 0.9f,
                //left
                0.6f, 0.6f, 0.6f, 0.6f,
                //right
                0.6f, 0.6f, 0.6f, 0.6f,
                //back
                0.8f, 0.8f, 0.8f, 0.8f,
                //left2
                0.6f, 0.6f, 0.6f, 0.6f,
                //right2
                0.6f, 0.6f, 0.6f, 0.6f,
                //top2
                1, 1, 1, 1,
                //left inner
                0.6f, 0.6f, 0.6f, 0.6f,
                //right inner
                0.6f, 0.6f, 0.6f, 0.6f,
            };
            float[] blend = new float[] {
                //front
                1, 1, 1, 1,
                //front dark
                1, 1, 1, 1,
                //top
                lenfac, 1, 1, lenfac,
                //notch
                1, 1, 1, 1,

                1, 1, 1, 1,
                //left
                lenfac, 1, 1, lenfac,
                //right
                lenfac, 1, 1, lenfac,

                //back
                0, 0, 0, 0,

                //left2
                0, lenfac, lenfac, 0,
                //right2
                0, lenfac, lenfac, 0,
                //top2
                0, lenfac, lenfac, 0,

                //left inner
                lenfac, lenfac, lenfac, lenfac,
                //right inner
                lenfac, lenfac, lenfac, lenfac,
            };
            int whiteQuads = 13;                       // 52 vertices
            whiteKeyIndexCount = whiteQuads * 6;

            Upload(Gl.ARRAY_BUFFER, whiteKeyCol, cols, Gl.STATIC_DRAW);
            Upload(Gl.ARRAY_BUFFER, whiteKeyBlend, blend, Gl.STATIC_DRAW);
            UploadIndices(whiteKeyIndx, Gl.MakeQuadIndices(whiteQuads));

            float[] offsets = new float[] {
                0, 0.6f,
                0.2f, 0.8f,
                0.4f, 1,
                0, 0.55f,
                0.15f, 0.7f,
                0.3f, 0.85f,
                0.45f, 1,
            };
            for (int i = 0; i < 7; i++)
            {
                foreach (var j in leftIndxs) verts[j] = offsets[i * 2];
                foreach (var j in rightIndxs) verts[j] = offsets[i * 2 + 1];
                Upload(Gl.ARRAY_BUFFER, whiteKeyVert[i], ToFloat(verts), Gl.STATIC_DRAW);
            }
            for (int i = 0; i < 7; i++)
            {
                foreach (var j in leftIndxs) verts[j] = offsets[i * 2];
                foreach (var j in rightIndxs) verts[j] = 1;
                Upload(Gl.ARRAY_BUFFER, whiteKeyVert[i + 7], ToFloat(verts), Gl.STATIC_DRAW);
            }
            for (int i = 0; i < 7; i++)
            {
                foreach (var j in leftIndxs) verts[j] = 0;
                foreach (var j in rightIndxs) verts[j] = offsets[i * 2 + 1];
                Upload(Gl.ARRAY_BUFFER, whiteKeyVert[i + 14], ToFloat(verts), Gl.STATIC_DRAW);
            }
            #endregion

            #region Black Key Model
            verts = new double[] {
                //front
                0, 0, -blackkeylen,
                0, 1, -blackkeylen + 1,
                1, 1, -blackkeylen + 1,
                1, 0, -blackkeylen,
                //top
                0, 1, -blackkeylen + 1,
                0, 1, -0,
                1, 1, -0,
                1, 1, -blackkeylen + 1,
                //left
                0, 0, 0,
                0, 0, -blackkeylen,
                0, 1, -blackkeylen + 1,
                0, 1, 0,
                //right
                1, 0, 0,
                1, 0, -blackkeylen,
                1, 1, -blackkeylen + 1,
                1, 1, 0,
                //back
                0, -1, 0,
                0, 1, 0,
                1, 1, 0,
                1, -1, 0,
                //left2
                0, 0, 0,
                0, 0, -blackkeylen,
                0, -1, -blackkeylen,
                0, -1, 0,
                //right2
                1, 0, 0,
                1, 0, -blackkeylen,
                1, -1, -blackkeylen,
                1, -1, 0,
                //front2
                0, 0, -blackkeylen,
                0, -1, -blackkeylen,
                1, -1, -blackkeylen,
                1, 0, -blackkeylen,
            };

            cols = new float[] {
                //front
                0.9f, 0.95f, 0.95f, 0.9f,
                //top
                1f, 0.94f, 0.94f, 1f,
                //left
                0.8f, 0.8f, 0.9f, 0.8f,
                //right
                0.8f, 0.8f, 0.9f, 0.8f,
                //back
                0.9f, 0.9f, 0.9f, 0.9f,
                //left2
                0.8f, 0.8f, 0.8f, 0.8f,
                //right2
                0.8f, 0.8f, 0.8f, 0.8f,
                //front2
                0.9f, 1f, 1f, 0.9f,
            };
            blend = new float[] {
                //front
                1, 1, 1, 1,
                //top
                1, 0, 0, 1,
                //left
                0, 1, 1, 0,
                //right
                0, 1, 1, 0,
                //back
                0, 0, 0, 0,
                //left2
                0, 1, 1, 0,
                //right2
                0, 1, 1, 0,
                //front2
                1, 1, 1, 1,
            };

            int blackQuads = 8;                        // 32 vertices
            blackKeyIndexCount = blackQuads * 6;

            Upload(Gl.ARRAY_BUFFER, blackKeyVert, ToFloat(verts), Gl.STATIC_DRAW);
            Upload(Gl.ARRAY_BUFFER, blackKeyCol, cols, Gl.STATIC_DRAW);
            Upload(Gl.ARRAY_BUFFER, blackKeyBlend, blend, Gl.STATIC_DRAW);
            UploadIndices(blackKeyIndx, Gl.MakeQuadIndices(blackQuads));
            #endregion

            keyPressFactor = new double[257];

            Initialized = true;
            Console.WriteLine("Initialised MIDITrailRenderer");
        }

        #region Vars
        int firstNote;
        int lastNote;
        bool sameWidth;
        double deltaTimeOnScreen;
        double noteDownSpeed;
        double noteUpSpeed;
        bool blockNotes;
        bool useVel;
        bool changeSize;
        bool changeTint;
        double tempoFrameStep;
        bool eatNotes;
        float auraStrength;
        bool auraEnabled;
        bool lightShade;
        bool tiltKeys;

        double fov;
        double aspect;
        double viewdist;
        double viewback;
        double viewheight;
        double viewpan;
        double viewoffset;
        double camAng;
        double camRot;
        double camSpin;

        double circleRadius;
        #endregion

        Color4[] keyColors = new Color4[514];
        double[] x1array = new double[257];
        double[] wdtharray = new double[257];
        double[] keyPressFactor = new double[257];
        double[] auraSize = new double[256];

        /// <summary>Translation(pan, -height, -offset) * Scale(1,1,-1) * RotZ * RotY * RotX * Perspective, shared by notes, keys and aura.</summary>
        Matrix4 ViewProjection()
        {
            return
                Matrix4.CreateTranslation((float)viewpan, -(float)viewheight, -(float)viewoffset) *
                Matrix4.CreateScale(1, 1, -1) *
                Matrix4.CreateRotationZ((float)camSpin) *
                Matrix4.CreateRotationY((float)camRot) *
                Matrix4.CreateRotationX((float)camAng) *
                Matrix4.CreatePerspectiveFieldOfView((float)fov, (float)aspect, 0.01f, 400);
        }

        void AddNoteQuad(
            double xa, double ya, double za,
            double xb, double yb, double zb,
            double xc, double yc, double zc,
            double xd, double yd, double zd,
            Color4 coll, Color4 colr, float shade)
        {
            int pos = noteBuffPos * 12;
            noteVertBuff[pos++] = (float)xa; noteVertBuff[pos++] = (float)ya; noteVertBuff[pos++] = (float)za;
            noteVertBuff[pos++] = (float)xb; noteVertBuff[pos++] = (float)yb; noteVertBuff[pos++] = (float)zb;
            noteVertBuff[pos++] = (float)xc; noteVertBuff[pos++] = (float)yc; noteVertBuff[pos++] = (float)zc;
            noteVertBuff[pos++] = (float)xd; noteVertBuff[pos++] = (float)yd; noteVertBuff[pos++] = (float)zd;

            pos = noteBuffPos * 16;
            noteColBuff[pos++] = coll.R; noteColBuff[pos++] = coll.G; noteColBuff[pos++] = coll.B; noteColBuff[pos++] = coll.A;
            noteColBuff[pos++] = coll.R; noteColBuff[pos++] = coll.G; noteColBuff[pos++] = coll.B; noteColBuff[pos++] = coll.A;
            noteColBuff[pos++] = colr.R; noteColBuff[pos++] = colr.G; noteColBuff[pos++] = colr.B; noteColBuff[pos++] = colr.A;
            noteColBuff[pos++] = colr.R; noteColBuff[pos++] = colr.G; noteColBuff[pos++] = colr.B; noteColBuff[pos++] = colr.A;

            pos = noteBuffPos * 4;
            noteShadeBuff[pos++] = shade;
            noteShadeBuff[pos++] = shade;
            noteShadeBuff[pos++] = shade;
            noteShadeBuff[pos++] = shade;

            noteBuffPos++;
        }

        public void RenderFrame(FastList<Note> notes, double midiTime, int finalCompositeBuff)
        {
            if (uploadedAuraVersion != AuraVersion) ReloadAuraTexture();
            Gl.glEnable(Gl.BLEND);
            Gl.glEnable(Gl.DEPTH_TEST);
            Gl.glDepthFunc(Gl.ALWAYS);

            Gl.glEnableVertexAttribArray(0);
            Gl.glEnableVertexAttribArray(1);
            Gl.glEnableVertexAttribArray(2);

            Gl.glBlendFunc(Gl.SRC_ALPHA, Gl.ONE_MINUS_SRC_ALPHA);

            buffer3d.BindBuffer();
            Gl.glViewport(0, 0, renderSettings.width, renderSettings.height);
            Gl.glClearColor(0f, 0f, 0f, 0f);
            Gl.glClear(Gl.COLOR_BUFFER_BIT);
            Gl.glClear(Gl.DEPTH_BUFFER_BIT);

            long nc = 0;
            firstNote = settings.firstNote;
            lastNote = settings.lastNote;
            sameWidth = settings.sameWidthNotes;
            deltaTimeOnScreen = NoteScreenTime;
            noteDownSpeed = settings.noteDownSpeed;
            noteUpSpeed = settings.noteUpSpeed;
            blockNotes = settings.boxNotes;
            useVel = settings.useVel;
            changeSize = settings.notesChangeSize;
            changeTint = settings.notesChangeTint;
            tempoFrameStep = 1 / (60000000 / Tempo / CurrentMidi.division) * (1000000.0 / renderSettings.fps);
            eatNotes = settings.eatNotes;
            auraStrength = (float)settings.auraStrength;
            auraEnabled = settings.auraEnabled;
            lightShade = settings.lightShade;
            tiltKeys = settings.tiltKeys;

            fov = settings.FOV;
            aspect = (double)renderSettings.width / renderSettings.height;
            viewdist = settings.viewdist;
            viewback = settings.viewback;
            viewheight = settings.viewHeight;
            viewpan = settings.viewPan;
            viewoffset = -settings.viewOffset;
            camAng = settings.camAng;
            camRot = settings.camRot;
            camSpin = settings.camSpin;
            for (int i = 0; i < 514; i++) keyColors[i] = Color4.Transparent;
            for (int i = 0; i < 256; i++) auraSize[i] = 0;
            for (int i = 0; i < keyPressFactor.Length; i++) keyPressFactor[i] = Math.Max(keyPressFactor[i] / 1.05 - noteUpSpeed, 0);
            float wdth;
            double wdthd;
            double x1d;
            double x2d;
            double y1;
            double y2;
            if (settings.sameWidthNotes)
            {
                for (int i = 0; i < 257; i++)
                {
                    x1array[i] = (float)(i - firstNote) / (lastNote - firstNote);
                    wdtharray[i] = 1.0f / (lastNote - firstNote);
                }
                circleRadius = 1.0f / (lastNote - firstNote);
            }
            else
            {
                double knmfn = keynum[firstNote];
                double knmln = keynum[lastNote - 1];
                if (blackKeys[firstNote]) knmfn = keynum[firstNote - 1] + 0.5;
                if (blackKeys[lastNote - 1]) knmln = keynum[lastNote] - 0.5;
                for (int i = 0; i < 257; i++)
                {
                    if (!blackKeys[i])
                    {
                        x1array[i] = (float)(keynum[i] - knmfn) / (knmln - knmfn + 1);
                        wdtharray[i] = 1.0f / (knmln - knmfn + 1);
                    }
                    else
                    {
                        int _i = i + 1;
                        wdth = (float)(0.6f / (knmln - knmfn + 1));
                        int bknum = keynum[i] % 5;
                        double offset = wdth / 2;
                        if (bknum == 0)
                        {
                            offset *= 1.4;
                        }
                        else if (bknum == 1)
                        {
                            offset *= 1 / 1.4;
                        }
                        if (bknum == 2)
                        {
                            offset *= 1.5;
                        }
                        else if (bknum == 4)
                        {
                            offset *= 1 / 1.5;
                        }
                        x1array[i] = (float)(keynum[_i] - knmfn) / (knmln - knmfn + 1) - offset;
                        wdtharray[i] = wdth;
                    }
                }
                circleRadius = (float)(0.6f / (knmln - knmfn + 1));
            }

            Matrix4 viewProj = ViewProjection();

            #region Notes
            noteBuffPos = 0;
            Gl.glUseProgram(noteShader);

            Matrix4 mvp = Matrix4.Identity;
            if (settings.verticalNotes) mvp = mvp * Matrix4.CreateRotationX(-(float)Math.PI / 2);
            mvp = mvp * viewProj;
            Gl.UniformMatrix4(uNoteMVP, mvp.M);

            double renderCutoff = midiTime + deltaTimeOnScreen;
            double renderStart = midiTime + NoteCollectorOffset;
            double maxAuraLen = tempoFrameStep * renderSettings.fps;

            if (blockNotes)
            {
                // pass 1: the side of each box
                foreach (Note n in notes)
                {
                    if (n.end >= renderStart || !n.hasEnded)
                    {
                        if (n.start < renderCutoff)
                        {
                            nc++;
                            int k = n.key;
                            if (!(k >= firstNote && k < lastNote)) continue;
                            Color4 coll = n.color.left;
                            Color4 colr = n.color.right;
                            float shade = 0;
                            x1d = x1array[k] - 0.5;
                            wdthd = wdtharray[k];
                            y1 = n.end - midiTime;
                            y2 = n.start - midiTime;
                            if (eatNotes && y1 < 0) y1 = 0;
                            if (eatNotes && y2 < 0) y2 = 0;
                            if (!n.hasEnded)
                                y1 = viewdist * deltaTimeOnScreen;
                            y1 /= deltaTimeOnScreen / viewdist;
                            y2 /= deltaTimeOnScreen / viewdist;

                            if (x1d < -viewpan) x1d += wdthd;
                            if (n.start < midiTime && (n.end > midiTime || !n.hasEnded))
                            {
                                double factor = 0.5;
                                if (n.hasEnded)
                                {
                                    double len = n.end - n.start;
                                    double offset = n.end - midiTime;
                                    if (offset > maxAuraLen) offset = maxAuraLen;
                                    if (len > maxAuraLen) len = maxAuraLen;
                                    factor = Math.Pow(offset / len, 0.3);
                                    factor /= 2;
                                }
                                else
                                {
                                    factor = 0.5;
                                }
                                if (changeTint)
                                    shade = (float)(factor * 0.7);
                                if (changeSize)
                                {
                                    if (x1d > 0)
                                        x1d -= wdthd * 0.3 * factor;
                                    else
                                        x1d += wdthd * 0.3 * factor;
                                }
                            }
                            if (lightShade)
                                shade += 0.2f;
                            else
                                shade -= 0.3f;

                            AddNoteQuad(
                                x1d, 0, y2,
                                x1d, 0, y1,
                                x1d, -wdthd, y1,
                                x1d, -wdthd, y2,
                                coll, colr, shade);
                            FlushNoteBuffer();
                        }
                        else break;
                    }
                }

                FlushNoteBuffer(false);

                // pass 2: the front face of each box
                foreach (Note n in notes)
                {
                    if (n.end >= renderStart || !n.hasEnded)
                    {
                        if (n.start < renderCutoff)
                        {
                            nc++;
                            int k = n.key;
                            if (!(k >= firstNote && k < lastNote)) continue;
                            Color4 coll = n.color.left;
                            Color4 colr = n.color.right;
                            float shade = 0;
                            x1d = x1array[k] - 0.5;
                            wdthd = wdtharray[k];
                            x2d = x1d + wdthd;
                            y1 = n.end - midiTime;
                            y2 = n.start - midiTime;
                            if (eatNotes && y1 < 0) y1 = 0;
                            if (eatNotes && y2 < 0) y2 = 0;
                            if (!n.hasEnded)
                                y1 = viewdist * deltaTimeOnScreen;
                            y1 /= deltaTimeOnScreen / viewdist;
                            y2 /= deltaTimeOnScreen / viewdist;
                            if ((settings.verticalNotes && y2 < viewheight) || (!settings.verticalNotes && y2 < viewoffset)) y2 = y1;
                            if (n.start < midiTime && (n.end > midiTime || !n.hasEnded))
                            {
                                double factor = 0.5;
                                if (n.hasEnded)
                                {
                                    double len = n.end - n.start;
                                    double offset = n.end - midiTime;
                                    if (offset > maxAuraLen) offset = maxAuraLen;
                                    if (len > maxAuraLen) len = maxAuraLen;
                                    factor = Math.Pow(offset / len, 0.3);
                                    factor /= 2;
                                }
                                else
                                {
                                    factor = 0.5;
                                }
                                if (changeTint)
                                    shade = (float)(factor * 0.7);
                                if (changeSize)
                                {
                                    x1d -= wdthd * 0.3 * factor;
                                    x2d += wdthd * 0.3 * factor;
                                }
                            }
                            shade -= 0.2f;

                            AddNoteQuad(
                                x2d, -wdthd, y2,
                                x2d, 0, y2,
                                x1d, 0, y2,
                                x1d, -wdthd, y2,
                                coll, colr, shade);
                            FlushNoteBuffer();
                        }
                        else break;
                    }
                }
            }

            // the top face (or the whole flat note)
            foreach (Note n in notes)
            {
                if (n.end >= renderStart || !n.hasEnded)
                {
                    if (n.start < renderCutoff)
                    {
                        nc++;
                        int k = n.key;
                        if (!(k >= firstNote && k < lastNote)) continue;
                        Color4 coll = n.color.left;
                        Color4 colr = n.color.right;
                        float shade = 0;

                        x1d = x1array[k] - 0.5;
                        wdthd = wdtharray[k];
                        x2d = x1d + wdthd;
                        y1 = n.end - midiTime;
                        y2 = n.start - midiTime;
                        if (eatNotes && y1 < 0) y1 = 0;
                        if (eatNotes && y2 < 0) y2 = 0;
                        if (!n.hasEnded)
                            y1 = viewdist * deltaTimeOnScreen;
                        y1 /= deltaTimeOnScreen / viewdist;
                        y2 /= deltaTimeOnScreen / viewdist;

                        if (n.start < midiTime && (n.end > midiTime || !n.hasEnded))
                        {
                            Color4 origcoll = keyColors[k * 2];
                            Color4 origcolr = keyColors[k * 2 + 1];
                            float blendfac = coll.A;
                            float revblendfac = 1 - blendfac;
                            keyColors[k * 2] = new Color4(
                                coll.R * blendfac + origcoll.R * revblendfac,
                                coll.G * blendfac + origcoll.G * revblendfac,
                                coll.B * blendfac + origcoll.B * revblendfac,
                                1f);
                            blendfac = colr.A * 0.8f;
                            revblendfac = 1 - blendfac;
                            keyColors[k * 2 + 1] = new Color4(
                                colr.R * blendfac + origcolr.R * revblendfac,
                                colr.G * blendfac + origcolr.G * revblendfac,
                                colr.B * blendfac + origcolr.B * revblendfac,
                                1f);
                            if (useVel)
                                keyPressFactor[k] = Math.Min(1, keyPressFactor[k] + noteDownSpeed * n.vel / 127.0);
                            else
                                keyPressFactor[k] = Math.Min(1, keyPressFactor[k] + noteDownSpeed);
                            double factor = 0;
                            double factor2 = Math.Pow(Math.Max(10 - (midiTime - n.start) / tempoFrameStep, 0), 2) / 600;
                            if (n.hasEnded)
                            {
                                double len = n.end - n.start;
                                double offset = n.end - midiTime;
                                if (offset > maxAuraLen) offset = maxAuraLen;
                                if (len > maxAuraLen) len = maxAuraLen;
                                factor = Math.Pow(offset / len, 0.3);
                                factor /= 2;
                            }
                            else
                            {
                                factor = 0.5;
                            }

                            if (auraSize[k] < factor + factor2) auraSize[k] = factor + factor2;

                            if (changeTint)
                                shade = (float)(factor * 0.7);
                            if (changeSize)
                            {
                                x1d -= wdthd * 0.3 * factor;
                                x2d += wdthd * 0.3 * factor;
                            }
                        }

                        AddNoteQuad(
                            x2d, 0, y2,
                            x2d, 0, y1,
                            x1d, 0, y1,
                            x1d, 0, y2,
                            coll, colr, shade);
                    }
                    FlushNoteBuffer();
                }
                else break;
            }

            FlushNoteBuffer(false);
            noteBuffPos = 0;

            LastNoteCount = nc;
            #endregion

            if ((!settings.verticalNotes && viewoffset < 0) || (settings.verticalNotes && viewheight < 0.025))
            {
                if (auraEnabled)
                {
                    Gl.glBlendFunc(Gl.SRC_ALPHA, Gl.ONE);
                    RenderAura(viewProj);
                    Gl.glBlendFunc(Gl.SRC_ALPHA, Gl.ONE_MINUS_SRC_ALPHA);
                }
                Gl.glDepthFunc(Gl.LESS);

                RenderKeyboard(viewProj);
            }
            else
            {
                Gl.glDepthFunc(Gl.LESS);
                RenderKeyboard(viewProj);
                Gl.glDepthFunc(Gl.ALWAYS);

                if (auraEnabled)
                {
                    Gl.glBlendFunc(Gl.SRC_ALPHA, Gl.ONE);
                    RenderAura(viewProj);
                    Gl.glBlendFunc(Gl.SRC_ALPHA, Gl.ONE_MINUS_SRC_ALPHA);
                }
                Gl.glDepthFunc(Gl.LESS);
            }

            Gl.glDisable(Gl.BLEND);
            Gl.glDisable(Gl.DEPTH_TEST);

            Gl.glDisableVertexAttribArray(0);
            Gl.glDisableVertexAttribArray(1);
            Gl.glDisableVertexAttribArray(2);

            // draw the 3D buffer into the compositor's buffer (same as Util.DrawScreenQuad on desktop)
            Gl.glBindFramebuffer(Gl.FRAMEBUFFER, finalCompositeBuff);
            Gl.glViewport(0, 0, renderSettings.width, renderSettings.height);
            buffer3d.BindTexture();
            Gl.glClear(Gl.COLOR_BUFFER_BIT);
            Gl.glClear(Gl.DEPTH_BUFFER_BIT);
            Gl.glUseProgram(copyShader);
            screenQuad.Draw(true);
        }

        void RenderAura(Matrix4 viewProj)
        {
            #region Aura
            double wdthd;
            float r, g, b, a, r2, g2, b2, a2;
            double x1d;
            double x2d;
            double y1;
            double y2;

            Gl.glUseProgram(circleShader);

            Gl.glBindTexture(Gl.TEXTURE_2D, auraTex);

            Matrix4 mvp = Matrix4.Identity;
            if (settings.verticalNotes) mvp = mvp *
                    Matrix4.CreateRotationX(-(float)Math.PI / 2) *
                    Matrix4.CreateTranslation(0, 0.025f, 0);
            mvp = mvp * viewProj;
            Gl.UniformMatrix4(uCircleMVP, mvp.M);

            circleBuffPos = 0;
            for (int n = firstNote; n < lastNote; n++)
            {
                x1d = x1array[n] - 0.5;
                wdthd = wdtharray[n];
                x2d = x1d + wdthd;
                double size = circleRadius * 12 * auraSize[n];
                if (!blackKeys[n])
                {
                    y2 = 0;
                    if (settings.sameWidthNotes)
                    {
                        int _n = n % 12;
                        if (_n == 0)
                            x2d += wdthd * 0.666f;
                        else if (_n == 2)
                        {
                            x1d -= wdthd / 3;
                            x2d += wdthd / 3;
                        }
                        else if (_n == 4)
                            x1d -= wdthd / 3 * 2;
                        else if (_n == 5)
                            x2d += wdthd * 0.75f;
                        else if (_n == 7)
                        {
                            x1d -= wdthd / 4;
                            x2d += wdthd / 2;
                        }
                        else if (_n == 9)
                        {
                            x1d -= wdthd / 2;
                            x2d += wdthd / 4;
                        }
                        else if (_n == 11)
                            x1d -= wdthd * 0.75f;
                    }
                }

                Color4 coll = keyColors[n * 2];
                Color4 colr = keyColors[n * 2 + 1];

                r = coll.R * auraStrength;
                g = coll.G * auraStrength;
                b = coll.B * auraStrength;
                a = coll.A * auraStrength;
                r2 = colr.R * auraStrength;
                g2 = colr.G * auraStrength;
                b2 = colr.B * auraStrength;
                a2 = colr.A * auraStrength;

                double middle = (x1d + x2d) / 2;
                x1d = middle - size;
                x2d = middle + size;
                y1 = size;
                y2 = -size;

                int pos = circleBuffPos * 12;
                circleVertBuff[pos++] = (float)x1d; circleVertBuff[pos++] = (float)y1; circleVertBuff[pos++] = 0;
                circleVertBuff[pos++] = (float)x1d; circleVertBuff[pos++] = (float)y2; circleVertBuff[pos++] = 0;
                circleVertBuff[pos++] = (float)x2d; circleVertBuff[pos++] = (float)y2; circleVertBuff[pos++] = 0;
                circleVertBuff[pos++] = (float)x2d; circleVertBuff[pos++] = (float)y1; circleVertBuff[pos++] = 0;

                pos = circleBuffPos * 16;
                circleColorBuff[pos++] = r; circleColorBuff[pos++] = g; circleColorBuff[pos++] = b; circleColorBuff[pos++] = a;
                circleColorBuff[pos++] = r; circleColorBuff[pos++] = g; circleColorBuff[pos++] = b; circleColorBuff[pos++] = a;
                circleColorBuff[pos++] = r2; circleColorBuff[pos++] = g2; circleColorBuff[pos++] = b2; circleColorBuff[pos++] = a2;
                circleColorBuff[pos++] = r2; circleColorBuff[pos++] = g2; circleColorBuff[pos++] = b2; circleColorBuff[pos++] = a2;

                pos = circleBuffPos * 8;
                circleUVBuff[pos++] = 0; circleUVBuff[pos++] = 0;
                circleUVBuff[pos++] = 1; circleUVBuff[pos++] = 0;
                circleUVBuff[pos++] = 1; circleUVBuff[pos++] = 1;
                circleUVBuff[pos++] = 0; circleUVBuff[pos++] = 1;

                circleBuffPos++;
            }
            Upload(Gl.ARRAY_BUFFER, circleVert, circleVertBuff, Gl.STREAM_DRAW);
            Gl.VertexAttribPointerF(0, 3, 12);
            Upload(Gl.ARRAY_BUFFER, circleColor, circleColorBuff, Gl.STREAM_DRAW);
            Gl.VertexAttribPointerF(1, 4, 16);
            Upload(Gl.ARRAY_BUFFER, circleUV, circleUVBuff, Gl.STREAM_DRAW);
            Gl.VertexAttribPointerF(2, 2, 8);
            Gl.glBindBuffer(Gl.ELEMENT_ARRAY_BUFFER, circleIndx);
            Gl.glDrawElements(Gl.TRIANGLES, circleBuffPos * 6, Gl.UNSIGNED_INT, 0);

            Gl.glBindTexture(Gl.TEXTURE_2D, 0);
            #endregion
        }

        void RenderKeyboard(Matrix4 viewProj)
        {
            if (!settings.showKeyboard) return;

            #region Keyboard
            float wdth;
            float wdth2;
            float x1;
            float x2;
            Matrix4 mvp;
            Color4[] origColors = new Color4[257];
            for (int k = firstNote; k < lastNote; k++)
            {
                if (isBlackNote(k))
                    origColors[k] = Color4.Black;
                else
                    origColors[k] = Color4.White;
            }

            Gl.glUseProgram(whiteKeyShader);

            Gl.glBindBuffer(Gl.ARRAY_BUFFER, whiteKeyCol);
            Gl.VertexAttribPointerF(1, 1, 4);
            Gl.glBindBuffer(Gl.ARRAY_BUFFER, whiteKeyBlend);
            Gl.VertexAttribPointerF(2, 1, 4);
            Gl.glBindBuffer(Gl.ELEMENT_ARRAY_BUFFER, whiteKeyIndx);

            for (int n = firstNote; n < lastNote; n++)
            {
                x1 = (float)x1array[n];
                wdth = (float)wdtharray[n];
                x2 = x1 + wdth;

                if (!blackKeys[n])
                {
                    if (settings.sameWidthNotes)
                    {
                        int _n = n % 12;
                        if (_n == 0)
                            x2 += wdth * 0.666f;
                        else if (_n == 2)
                        {
                            x1 -= wdth / 3;
                            x2 += wdth / 3;
                        }
                        else if (_n == 4)
                            x1 -= wdth / 3 * 2;
                        else if (_n == 5)
                            x2 += wdth * 0.75f;
                        else if (_n == 7)
                        {
                            x1 -= wdth / 4;
                            x2 += wdth / 2;
                        }
                        else if (_n == 9)
                        {
                            x1 -= wdth / 2;
                            x2 += wdth / 4;
                        }
                        else if (_n == 11)
                            x1 -= wdth * 0.75f;
                        wdth2 = wdth * 2;
                    }
                    else
                    {
                        wdth2 = wdth;
                    }
                }
                else continue;
                wdth = x2 - x1;
                x1 -= 0.5f;

                var coll = keyColors[n * 2];
                var colr = keyColors[n * 2 + 1];
                var origcol = origColors[n];
                float blendfac = coll.A * 0.8f;
                float revblendfac = 1 - blendfac;
                coll = new Color4(
                    coll.R * blendfac + origcol.R * revblendfac,
                    coll.G * blendfac + origcol.G * revblendfac,
                    coll.B * blendfac + origcol.B * revblendfac,
                    1f);
                blendfac = colr.A * 0.8f;
                revblendfac = 1 - blendfac;
                colr = new Color4(
                    colr.R * blendfac + origcol.R * revblendfac,
                    colr.G * blendfac + origcol.G * revblendfac,
                    colr.B * blendfac + origcol.B * revblendfac,
                    1f);

                Gl.glUniform4f(uWhiteKeycoll, coll.R, coll.G, coll.B, coll.A);
                Gl.glUniform4f(uWhiteKeycolr, colr.R, colr.G, colr.B, colr.A);
                float scale = 1;
                if (!sameWidth)
                {
                    scale = 1.17f;
                    wdth2 = wdth;
                }
                else wdth2 = (float)wdtharray[firstNote] * 2;
                mvp = Matrix4.Identity *
                    Matrix4.CreateScale(0.95f, 1, scale);
                if (tiltKeys)
                    mvp = mvp *
                        Matrix4.CreateTranslation(0, 0, -4) *
                        Matrix4.CreateRotationX((float)-keyPressFactor[n] / 20) *
                        Matrix4.CreateTranslation(0, 0, 4);
                else
                    mvp = mvp * Matrix4.CreateTranslation(0, (float)-keyPressFactor[n] / 2, 0);
                mvp = mvp *
                    Matrix4.CreateTranslation(0, -0.3f, 0) *
                    (sameWidth ? Matrix4.CreateScale(wdth, wdth2 * 0.9f, wdth2 * 1.01f) : Matrix4.CreateScale(wdth2, wdth2, wdth2)) *
                    Matrix4.CreateTranslation(x1, 0, 0) *
                    (settings.verticalNotes ? Matrix4.CreateTranslation(0, 0, 0.05f) : Matrix4.Identity) *
                    viewProj;

                if (n == firstNote)
                    Gl.glBindBuffer(Gl.ARRAY_BUFFER, whiteKeyVert[keynum[n] % 7 + 14]);
                else if (n == lastNote - 1)
                    Gl.glBindBuffer(Gl.ARRAY_BUFFER, whiteKeyVert[keynum[n] % 7 + 7]);
                else
                    Gl.glBindBuffer(Gl.ARRAY_BUFFER, whiteKeyVert[keynum[n] % 7]);
                Gl.VertexAttribPointerF(0, 3, 12);
                Gl.UniformMatrix4(uWhiteKeyMVP, mvp.M);
                Gl.glDrawElements(Gl.TRIANGLES, whiteKeyIndexCount, Gl.UNSIGNED_INT, 0);
            }

            Gl.glUseProgram(blackKeyShader);

            Gl.glBindBuffer(Gl.ARRAY_BUFFER, blackKeyVert);
            Gl.VertexAttribPointerF(0, 3, 12);
            Gl.glBindBuffer(Gl.ARRAY_BUFFER, blackKeyCol);
            Gl.VertexAttribPointerF(1, 1, 4);
            Gl.glBindBuffer(Gl.ARRAY_BUFFER, blackKeyBlend);
            Gl.VertexAttribPointerF(2, 1, 4);
            Gl.glBindBuffer(Gl.ELEMENT_ARRAY_BUFFER, blackKeyIndx);

            for (int n = firstNote; n < lastNote; n++)
            {
                x1 = (float)x1array[n];
                wdth = (float)wdtharray[n];
                x1 -= 0.5f;

                if (!blackKeys[n]) continue;

                var coll = keyColors[n * 2];
                var colr = keyColors[n * 2 + 1];
                var origcol = origColors[n];
                float blendfac = coll.A * 0.8f;
                float revblendfac = 1 - blendfac;
                coll = new Color4(
                    coll.R * blendfac + origcol.R * revblendfac,
                    coll.G * blendfac + origcol.G * revblendfac,
                    coll.B * blendfac + origcol.B * revblendfac,
                    1f);
                blendfac = colr.A * 0.8f;
                revblendfac = 1 - blendfac;
                colr = new Color4(
                    colr.R * blendfac + origcol.R * revblendfac,
                    colr.G * blendfac + origcol.G * revblendfac,
                    colr.B * blendfac + origcol.B * revblendfac,
                    1f);

                Gl.glUniform4f(uBlackKeycoll, coll.R, coll.G, coll.B, coll.A);
                Gl.glUniform4f(uBlackKeycolr, colr.R, colr.G, colr.B, colr.A);

                float vertOffset = 1.2f;
                if (!sameWidth) vertOffset = 1.1f;
                float scale = 1;
                if (!sameWidth) scale = 0.97f;
                mvp = Matrix4.Identity *
                    Matrix4.CreateScale(0.95f, 1, scale);
                if (tiltKeys)
                    mvp = mvp *
                        Matrix4.CreateTranslation(0, 0, -4) *
                        Matrix4.CreateRotationX((float)-keyPressFactor[n] / 20) *
                        Matrix4.CreateTranslation(0, 0, 4);
                else
                    mvp = mvp * Matrix4.CreateTranslation(0, (float)-keyPressFactor[n] / 1.2f, 0);
                mvp = mvp *
                    Matrix4.CreateTranslation(0, vertOffset, 0) *
                    Matrix4.CreateScale(wdth, wdth / scale, wdth) *
                    Matrix4.CreateTranslation(x1, 0, 0) *
                    (settings.verticalNotes ? Matrix4.CreateTranslation(0, 0, 0.05f) : Matrix4.Identity) *
                    viewProj;

                Gl.UniformMatrix4(uBlackKeyMVP, mvp.M);
                Gl.glDrawElements(Gl.TRIANGLES, blackKeyIndexCount, Gl.UNSIGNED_INT, 0);
            }
            #endregion
        }

        public void ReloadTrackColors()
        {
            if (NoteColors == null) return;
            var cols = NotePalette.GetColors(settings.palette, NoteColors.Length);

            for (int i = 0; i < NoteColors.Length; i++)
            {
                for (int j = 0; j < NoteColors[i].Length; j++)
                {
                    if (NoteColors[i][j].isDefault)
                    {
                        NoteColors[i][j].left = cols[i * 32 + j * 2];
                        NoteColors[i][j].right = cols[i * 32 + j * 2 + 1];
                    }
                }
            }
        }

        void FlushNoteBuffer(bool check = true)
        {
            if (noteBuffPos < noteBuffLen && check) return;
            if (noteBuffPos == 0) return;
            Gl.glBindBuffer(Gl.ARRAY_BUFFER, noteVert);
            Gl.BufferData(Gl.ARRAY_BUFFER, noteVertBuff, noteBuffPos * 12, Gl.STREAM_DRAW);
            Gl.VertexAttribPointerF(0, 3, 12);
            Gl.glBindBuffer(Gl.ARRAY_BUFFER, noteCol);
            Gl.BufferData(Gl.ARRAY_BUFFER, noteColBuff, noteBuffPos * 16, Gl.STREAM_DRAW);
            Gl.VertexAttribPointerF(1, 4, 16);
            Gl.glBindBuffer(Gl.ARRAY_BUFFER, noteShade);
            Gl.BufferData(Gl.ARRAY_BUFFER, noteShadeBuff, noteBuffPos * 4, Gl.STREAM_DRAW);
            Gl.VertexAttribPointerF(2, 1, 4);
            Gl.glBindBuffer(Gl.ELEMENT_ARRAY_BUFFER, noteIndx);
            Gl.glDrawElements(Gl.TRIANGLES, noteBuffPos * 6, Gl.UNSIGNED_INT, 0);
            noteBuffPos = 0;
        }

        static bool isBlackNote(int n)
        {
            n = n % 12;
            return n == 1 || n == 3 || n == 6 || n == 8 || n == 10;
        }
    }
}
