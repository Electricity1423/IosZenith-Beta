/*
 * zenith_ffmpeg - run the ffmpeg command line tool inside the app process.
 *
 * iOS apps cannot launch another executable, so Zenith's "pipe raw frames
 * into ffmpeg.exe" design becomes:
 *
 *    1. create a named pipe (FIFO) in the app's temp directory
 *    2. run ffmpeg on a worker thread with  "-f rawvideo ... -i <fifo>"
 *    3. write each rendered frame into the FIFO
 *
 * This keeps the command line (and so every ffmpeg option, including the
 * user's "custom ffmpeg options") identical to the desktop version.
 *
 * Only one ffmpeg run can be active at a time (ffmpeg keeps its state in
 * globals).  A second call to zenith_ffmpeg_execute blocks until the first
 * has finished.
 */
#ifndef ZENITH_FFMPEG_H
#define ZENITH_FFMPEG_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

#if defined(__GNUC__)
#define ZENITH_API __attribute__((visibility("default")))
#else
#define ZENITH_API
#endif

/* Version string of the linked libavcodec/ffmpeg build. */
ZENITH_API const char *zenith_ffmpeg_version(void);

/*
 * Run `ffmpeg argv[1..]`  (argv[0] should be "ffmpeg").  Blocks until done.
 * Returns ffmpeg's exit status: 0 = success, non-zero = failure.
 * Call from a worker thread, never from the UI thread.
 */
ZENITH_API int zenith_ffmpeg_execute(int argc, char **argv);

/*
 * Same as zenith_ffmpeg_execute, but runs ffmpeg on its own thread (8 MiB
 * stack) and returns immediately.  `running` is already 1 when this returns,
 * so a FIFO writer opened afterwards can tell "not started yet" from
 * "already failed".  Returns 0 if started, -1 if another run is active or
 * the thread could not be created.  Arguments are copied.
 */
ZENITH_API int zenith_ffmpeg_start(int argc, char **argv);

/* Wait for a run started with zenith_ffmpeg_start; returns its exit status. */
ZENITH_API int zenith_ffmpeg_wait(void);

/* 1 from zenith_ffmpeg_start/execute until ffmpeg has returned. */
ZENITH_API int zenith_ffmpeg_is_running(void);

/* Ask the running ffmpeg to finish (like Ctrl-C).  Safe from any thread. */
ZENITH_API void zenith_ffmpeg_cancel(void);

/*
 * Copy log output produced since the last call into `buf` (NUL terminated,
 * at most `size - 1` bytes) and remove it from the internal buffer.
 * Returns the number of bytes copied.  ffmpeg's "frame=... fps=..." progress
 * lines come through here.  If more than 64 KiB accumulates the oldest text
 * is dropped.
 */
ZENITH_API int zenith_ffmpeg_read_log(char *buf, int size);

/* Set ffmpeg's log level (AV_LOG_* values, e.g. 32 = info, 24 = warning). */
ZENITH_API void zenith_ffmpeg_set_log_level(int level);

/* ---- FIFO helpers -------------------------------------------------------- */

/* Create (replace) a FIFO at `path`.  Returns 0 or -1 (errno set). */
ZENITH_API int zenith_ffmpeg_make_fifo(const char *path);

/*
 * Open the write end of a FIFO.  A FIFO write end can only be opened once
 * a reader exists, so this polls until ffmpeg has opened it.  Gives up and
 * returns -1 if ffmpeg is not running (it exited early, e.g. bad arguments)
 * or after `timeout_ms`.  Returns a file descriptor.
 */
ZENITH_API int zenith_ffmpeg_open_fifo_writer(const char *path, int timeout_ms);

/*
 * Write exactly `len` bytes.  Returns 0 on success, -1 if the reader went
 * away (ffmpeg finished or failed) or on error.  SIGPIPE is suppressed.
 */
ZENITH_API int zenith_ffmpeg_write_fully(int fd, const void *data, size_t len);

/* Close a descriptor from open_fifo_writer.  Closing the writer is what
 * tells ffmpeg the video has ended. */
ZENITH_API void zenith_ffmpeg_close_fd(int fd);

#ifdef __cplusplus
}
#endif

#endif /* ZENITH_FFMPEG_H */
