using System;

namespace ZenithEngine
{
    /// <summary>
    /// The renderer contract (the desktop IPluginRender without the WPF parts).
    /// </summary>
    public interface IMidiRenderer : IDisposable
    {
        string Name { get; }
        bool Initialized { get; }
        bool ManualNoteDelete { get; }
        double NoteCollectorOffset { get; }

        NoteColor[][] NoteColors { set; }
        double Tempo { set; }
        MidiInfo CurrentMidi { set; }

        double NoteScreenTime { get; }
        long LastNoteCount { get; }

        void Init();
        void RenderFrame(FastList<Note> notes, double midiTime, int finalCompositeBuff);
        void ReloadTrackColors();
    }
}
