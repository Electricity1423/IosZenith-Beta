using System;
using System.Collections.Generic;

namespace ZenithEngine
{
    /// <summary>
    /// The four built-in note colour palettes of Zenith (generated, not image files),
    /// plus the track/channel colour assignment from NoteColorPalettePick.GetColors.
    /// </summary>
    public static class NotePalette
    {
        public static readonly string[] Names =
        {
            "Random",
            "Random Gradients",
            "Random Alpha Gradients",
            "Random with Alpha",
        };

        const float Mult = 0.12345f;

        // Desktop goes through System.Drawing: Color4 -> Color truncates to 8 bits
        // ((int)(v*255)), GetPixel then divides by 255.  Reproduce that.
        static Color4 Quantise(Color4 c)
        {
            return new Color4(
                (int)(c.R * 255) / 255f,
                (int)(c.G * 255) / 255f,
                (int)(c.B * 255) / 255f,
                (int)(c.A * 255) / 255f);
        }

        static Color4[] Build(string name, out int width)
        {
            const int h = 8;
            switch (name)
            {
                case "Random Gradients":
                case "Random Alpha Gradients":
                {
                    float alpha = name == "Random Gradients" ? 1f : 0.8f;
                    width = 32;
                    var px = new Color4[width * h];
                    for (int i = 0; i < 32 * 8; i++)
                    {
                        px[i] = Quantise(Color4.FromHsv((i * Mult) % 1f, 1f, 1f, alpha));
                        i++;
                        px[i] = Quantise(Color4.FromHsv(((i - 1) * Mult + 0.166f) % 1f, 1f, 1f, alpha));
                    }
                    return px;
                }
                case "Random with Alpha":
                {
                    width = 16;
                    var px = new Color4[width * h];
                    for (int i = 0; i < 16 * 8; i++)
                        px[i] = Quantise(Color4.FromHsv((i * Mult) % 1f, 1f, 1f, 0.8f));
                    return px;
                }
                default: // "Random"
                {
                    width = 16;
                    var px = new Color4[width * h];
                    for (int i = 0; i < 16 * 8; i++)
                        px[i] = Quantise(Color4.FromHsv((i * Mult) % 1f, 1f, 1f, 1f));
                    return px;
                }
            }
        }

        /// <summary>
        /// Two colours (left, right) for each of 16 channels of each track:
        /// result[track * 32 + channel * 2] and [... + 1].  Same shuffle as the desktop
        /// version (System.Random with seed 0), so colours match across platforms.
        /// </summary>
        public static Color4[] GetColors(string name, int tracks, int seed = 0, bool randomise = true)
        {
            var img = Build(name, out int width);
            const int height = 8;

            var r = new Random(seed);
            var order = new double[tracks * 16];
            var coords = new int[tracks * 16];
            for (int i = 0; i < order.Length; i++)
            {
                order[i] = r.NextDouble();
                coords[i] = i;
            }
            if (randomise) Array.Sort(order, coords);

            var cols = new List<Color4>(tracks * 32);
            for (int i = 0; i < tracks; i++)
            {
                for (int j = 0; j < 16; j++)
                {
                    int y = coords[i * 16 + j];
                    int x = y % 16;
                    y = y - x;
                    y /= 16;
                    int row = y % height;
                    if (width == 16)
                    {
                        cols.Add(img[row * width + x]);
                        cols.Add(img[row * width + x]);
                    }
                    else
                    {
                        cols.Add(img[row * width + x * 2]);
                        cols.Add(img[row * width + x * 2 + 1]);
                    }
                }
            }
            return cols.ToArray();
        }
    }
}
