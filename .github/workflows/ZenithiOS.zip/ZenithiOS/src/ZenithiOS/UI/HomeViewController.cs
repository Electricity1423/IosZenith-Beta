using System;
using System.IO;
using System.Threading.Tasks;
using Foundation;
using UIKit;
using UniformTypeIdentifiers;
using ZenithEngine;

namespace Zenith.iOS.UI
{
    internal sealed class HomeViewController : FormViewController
    {
        UILabel info;
        UIActivityIndicatorView spinner;
        UIButton previewBtn, exportBtn;
        bool loading;

        public HomeViewController() { Title = "Zenith MIDI"; }

        protected override void Build()
        {
            AddHeader("MIDI file");
            info = new UILabel { Text = "No file loaded.", Lines = 0, TextColor = UIColor.SecondaryLabel };
            Stack.AddArrangedSubview(info);
            spinner = new UIActivityIndicatorView(UIActivityIndicatorViewStyle.Medium) { HidesWhenStopped = true };
            Stack.AddArrangedSubview(spinner);
            AddButton("Choose MIDI file…", PickMidi, true);

            AddHeader("Render");
            previewBtn = AddButton("Preview", () => NavigationController.PushViewController(new PreviewViewController(), true));
            exportBtn = AddButton("Export video…", () => NavigationController.PushViewController(new ExportViewController(), true));
            AddButton("MIDITrail+ settings", () => NavigationController.PushViewController(new SettingsViewController(), true));
            SetReady(false);

            AddNote("Zenith for iOS renders with the MIDITrail+ visualiser. Exports are encoded on-device with ffmpeg " +
                    "(hardware H.264 / HEVC). Keep the app open while exporting. Finished videos appear in the Files app under Zenith MIDI.");
        }

        void SetReady(bool ready)
        {
            previewBtn.Enabled = ready; exportBtn.Enabled = ready;
            previewBtn.Alpha = exportBtn.Alpha = ready ? 1f : 0.45f;
        }

        void PickMidi()
        {
            var types = new System.Collections.Generic.List<UTType>();
            foreach (var ext in new[] { "mid", "midi" })
            {
                var t = UTType.CreateFromExtension(ext);
                if (t != null) types.Add(t);
            }
            if (types.Count == 0) types.Add(UTType.Data);
            var picker = new UIDocumentPickerViewController(types.ToArray(), true);
            picker.Delegate = new PickerDelegate(url => LoadFromUrl(url, false));
            PresentViewController(picker, true, null);
        }

        public void LoadFromExternalUrl(NSUrl url)
        {
            // security-scoped when it comes from another app
            LoadFromUrl(url, true);
        }

        void LoadFromUrl(NSUrl url, bool scoped)
        {
            if (loading) return;
            loading = true;
            SetReady(false);
            info.Text = "Loading " + url.LastPathComponent + "…";
            spinner.StartAnimating();

            string name = url.LastPathComponent;
            string tmp = Path.Combine(Path.GetTempPath(), "zenith_current.mid");
            bool access = scoped && url.StartAccessingSecurityScopedResource();
            string source = url.Path;

            Task.Run(() =>
            {
                try
                {
                    File.Copy(source, tmp, true);
                    if (access) url.StopAccessingSecurityScopedResource();

                    var old = AppState.Midi; AppState.Midi = null;
                    try { old?.Dispose(); } catch { }

                    var midi = new MidiFile(tmp, new RenderSettings());
                    InvokeOnMainThread(() =>
                    {
                        AppState.Midi = midi; AppState.MidiName = name;
                        var i = midi.info;
                        info.Text = name + "\n" + i.trackCount + " tracks · " + i.noteCount.ToString("N0") + " notes · " +
                                    "PPQ " + i.division;
                        SetReady(true);
                        Done();
                    });
                }
                catch (Exception ex)
                {
                    if (access) url.StopAccessingSecurityScopedResource();
                    InvokeOnMainThread(() => { info.Text = "Couldn't load that file."; Done(); Alert("Couldn't load MIDI", ex.Message); });
                }
            });

            void Done() { loading = false; spinner.StopAnimating(); }
        }

        sealed class PickerDelegate : UIDocumentPickerDelegate
        {
            readonly Action<NSUrl> picked;
            public PickerDelegate(Action<NSUrl> picked) { this.picked = picked; }
            public override void DidPickDocument(UIDocumentPickerViewController controller, NSUrl[] urls)
            {
                if (urls != null && urls.Length > 0) picked(urls[0]);
            }
        }
    }

    internal sealed class AudioPickerDelegate : UIDocumentPickerDelegate
    {
        readonly Action<NSUrl> picked;
        public AudioPickerDelegate(Action<NSUrl> picked) { this.picked = picked; }
        public override void DidPickDocument(UIDocumentPickerViewController controller, NSUrl[] urls)
        {
            if (urls != null && urls.Length > 0) picked(urls[0]);
        }
    }
}
