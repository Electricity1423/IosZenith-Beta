/*
 * Host-side test for the in-process ffmpeg entry point (zenith_ffmpeg.c plus the
 * patched fftools).  Exercises exactly the pattern the iOS app uses:
 *
 *   fifo -> "-f rawvideo -i fifo" -> encoder -> mp4
 *
 * and checks that ffmpeg can be run many times in one process.
 *
 *   usage: test_runner <work-dir>
 */
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#include "zenith_ffmpeg.h"

#define W 64
#define H 48
#define FRAMES 90

static int failures = 0;
#define CHECK(cond, ...) do { if (!(cond)) { printf("  FAIL: " __VA_ARGS__); printf("\n"); failures++; } else { printf("  ok:   " __VA_ARGS__); printf("\n"); } } while (0)

static void drain_log(char *out, size_t cap)
{
    char tmp[4096];
    size_t len = 0;
    int n;
    out[0] = 0;
    while ((n = zenith_ffmpeg_read_log(tmp, sizeof(tmp))) > 0) {
        if (len + n < cap) { memcpy(out + len, tmp, n); len += n; out[len] = 0; }
    }
}

static void make_frame(unsigned char *f, int i)
{
    /* BGRA, a moving gradient */
    for (int y = 0; y < H; y++)
        for (int x = 0; x < W; x++) {
            unsigned char *p = f + (y * W + x) * 4;
            p[0] = (unsigned char)(x * 4 + i);
            p[1] = (unsigned char)(y * 5);
            p[2] = (unsigned char)(i * 2);
            p[3] = 255;
        }
}

static int file_size(const char *p)
{
    struct stat st;
    return stat(p, &st) == 0 ? (int)st.st_size : -1;
}

/* Run ffmpeg on a thread, feed `frames` frames to each fifo, close, wait. */
static int run_with_fifos(char **argv, int argc, const char **fifos, int nfifos, int frames)
{
    unsigned char *frame = malloc(W * H * 4);
    int fds[4] = { -1, -1, -1, -1 };
    int write_failed = 0;

    for (int i = 0; i < nfifos; i++)
        zenith_ffmpeg_make_fifo(fifos[i]);

    if (zenith_ffmpeg_start(argc, argv) != 0) { free(frame); return -999; }

    for (int i = 0; i < nfifos; i++) {
        fds[i] = zenith_ffmpeg_open_fifo_writer(fifos[i], 10000);
        if (fds[i] < 0) { write_failed = 1; break; }
    }
    for (int f = 0; f < frames && !write_failed; f++) {
        make_frame(frame, f);
        for (int i = 0; i < nfifos; i++)
            if (zenith_ffmpeg_write_fully(fds[i], frame, W * H * 4) != 0) { write_failed = 1; break; }
    }
    for (int i = 0; i < nfifos; i++) zenith_ffmpeg_close_fd(fds[i]);
    free(frame);
    int ret = zenith_ffmpeg_wait();
    for (int i = 0; i < nfifos; i++) unlink(fifos[i]);
    if (ret != 0) return ret;
    return write_failed ? -998 : 0;
}

int main(int argc, char **argv)
{
    char dir[512], path[600], log[65536];
    char out1[600], out2[600], fifo1[600], fifo2[600], wav[600], out3[600];
    setvbuf(stdout, NULL, _IONBF, 0);
    if (argc < 2) { fprintf(stderr, "usage: %s workdir\n", argv[0]); return 2; }
    snprintf(dir, sizeof dir, "%s", argv[1]);
    mkdir(dir, 0700);
    snprintf(out1, sizeof out1, "%s/video.mp4", dir);
    snprintf(out2, sizeof out2, "%s/mask.mp4", dir);
    snprintf(out3, sizeof out3, "%s/withaudio.mp4", dir);
    snprintf(fifo1, sizeof fifo1, "%s/f1", dir);
    snprintf(fifo2, sizeof fifo2, "%s/f2", dir);
    snprintf(wav, sizeof wav, "%s/tone.wav", dir);
    (void)path;

    printf("ffmpeg version: %s\n", zenith_ffmpeg_version());
    zenith_ffmpeg_set_log_level(32);

    const char *wh = "64x48";

    /* 1. single video, mirrors RenderWindow.startNewFF() without audio */
    printf("[1] fifo -> mp4\n");
    {
        char *a[] = { "ffmpeg", "-hide_banner", "-nostdin", "-y",
            "-f", "rawvideo", "-s", (char *)wh, "-pix_fmt", "bgra", "-r", "30", "-i", fifo1,
            "-vf", "vflip", "-pix_fmt", "yuv420p", "-c:v", "mpeg4", "-b:v", "500k", out1 };
        int ret = run_with_fifos(a, (int)(sizeof a / sizeof *a), (const char *[]){ fifo1 }, 1, FRAMES);
        drain_log(log, sizeof log);
        CHECK(ret == 0, "exit status 0 (got %d)", ret);
        CHECK(file_size(out1) > 1000, "output exists (%d bytes)", file_size(out1));
        CHECK(strstr(log, "frame=") != NULL || strstr(log, "frame ") != NULL, "progress lines captured in log");
    }

    /* 2. a second run in the same process: video + alpha mask from ONE input.
     *    (Two FIFO inputs deadlock if opened one after the other, because
     *    ffmpeg reads from input 0 before it opens input 1.  One pipe and
     *    alphaextract avoids that and halves the readback cost.) */
    printf("[2] one fifo -> two mp4 (video + alpha mask), second run in same process\n");
    {
        char *a[] = { "ffmpeg", "-hide_banner", "-nostdin", "-y",
            "-f", "rawvideo", "-s", (char *)wh, "-pix_fmt", "bgra", "-r", "30", "-i", fifo1,
            "-filter_complex", "[0:v]vflip,split=2[c][a];[a]alphaextract[m]",
            "-map", "[c]", "-pix_fmt", "yuv420p", "-c:v", "mpeg4", "-b:v", "500k", out1,
            "-map", "[m]", "-pix_fmt", "yuv420p", "-c:v", "mpeg4", "-b:v", "500k", out2 };
        int ret = run_with_fifos(a, (int)(sizeof a / sizeof *a), (const char *[]){ fifo1 }, 1, FRAMES);
        drain_log(log, sizeof log);
        CHECK(ret == 0, "exit status 0 (got %d)", ret);
        CHECK(file_size(out1) > 1000, "video output exists (%d bytes)", file_size(out1));
        CHECK(file_size(out2) > 500, "mask output exists (%d bytes)", file_size(out2));
        if (ret != 0) printf("%s\n", log);
    }

    /* 3. verify the file really contains FRAMES decodable frames */
    printf("[3] decode check\n");
    {
        char *a[] = { "ffmpeg", "-hide_banner", "-nostdin", "-i", out1, "-c:v", "wrapped_avframe", "-f", "null", "-" };
        int ret = zenith_ffmpeg_execute((int)(sizeof a / sizeof *a), a);
        drain_log(log, sizeof log);
        CHECK(ret == 0, "decode exit status 0 (got %d)", ret);
        int got = -1;
        const char *fp = strstr(log, "frame=");
        for (const char *q = fp; q; q = strstr(q + 1, "frame=")) fp = q;   /* last progress line */
        if (fp) sscanf(fp + 6, "%d", &got);
        CHECK(got == FRAMES, "decoded %d frames (expected %d)", got, FRAMES);
    }

    /* 4. audio input + AAC like 'Include audio' */
    printf("[4] video fifo + wav -> mp4/aac\n");
    {
        FILE *f = fopen(wav, "wb");
        int rate = 44100, n = rate * 3;
        unsigned int dsz = n * 2, rsz = 36 + dsz, sr = rate, br = rate * 2;
        unsigned short fmt = 1, ch = 1, ba = 2, bps = 16;
        unsigned int fsz = 16;
        fwrite("RIFF", 1, 4, f); fwrite(&rsz, 4, 1, f); fwrite("WAVEfmt ", 1, 8, f);
        fwrite(&fsz, 4, 1, f); fwrite(&fmt, 2, 1, f); fwrite(&ch, 2, 1, f);
        fwrite(&sr, 4, 1, f); fwrite(&br, 4, 1, f); fwrite(&ba, 2, 1, f); fwrite(&bps, 2, 1, f);
        fwrite("data", 1, 4, f); fwrite(&dsz, 4, 1, f);
        for (int i = 0; i < n; i++) {
            short s = (short)(8000 * ((i / 50) % 2 ? 1 : -1));
            fwrite(&s, 2, 1, f);
        }
        fclose(f);

        char *a[] = { "ffmpeg", "-hide_banner", "-nostdin", "-y",
            "-f", "rawvideo", "-s", (char *)wh, "-pix_fmt", "bgra", "-r", "30", "-i", fifo1,
            "-itsoffset", "0.00", "-i", wav, "-vf", "vflip", "-pix_fmt", "yuv420p",
            "-c:v", "mpeg4", "-c:a", "aac", "-b:v", "500k", "-shortest", out3 };
        int ret = run_with_fifos(a, (int)(sizeof a / sizeof *a), (const char *[]){ fifo1 }, 1, FRAMES);
        drain_log(log, sizeof log);
        CHECK(ret == 0, "exit status 0 (got %d)", ret);
        CHECK(file_size(out3) > 1000, "output exists (%d bytes)", file_size(out3));
        if (ret != 0) printf("%s\n", log);
    }

    /* 5. failure: ffmpeg gives up early (unknown encoder) - writer must not hang */
    printf("[5] failing run does not hang the writer\n");
    {
        char *a[] = { "ffmpeg", "-hide_banner", "-nostdin", "-y",
            "-f", "rawvideo", "-s", (char *)wh, "-pix_fmt", "bgra", "-r", "30", "-i", fifo1,
            "-c:v", "no_such_encoder", out1 };
        int ret = run_with_fifos(a, (int)(sizeof a / sizeof *a), (const char *[]){ fifo1 }, 1, FRAMES);
        drain_log(log, sizeof log);
        CHECK(ret != 0, "reports failure (got %d)", ret);
    }

    /* 6. state is clean again after a failure */
    printf("[6] run after a failed run\n");
    {
        char *a[] = { "ffmpeg", "-hide_banner", "-nostdin", "-y",
            "-f", "rawvideo", "-s", (char *)wh, "-pix_fmt", "bgra", "-r", "30", "-i", fifo1,
            "-vf", "vflip", "-pix_fmt", "yuv420p", "-c:v", "mpeg4", out1 };
        int ret = run_with_fifos(a, (int)(sizeof a / sizeof *a), (const char *[]){ fifo1 }, 1, 30);
        drain_log(log, sizeof log);
        CHECK(ret == 0, "exit status 0 (got %d)", ret);
    }

    /* 7. cancel: stop mid-render and still get a playable file */
    printf("[7] cancel mid-run finalises output\n");
    {
        char *a[] = { "ffmpeg", "-hide_banner", "-nostdin", "-y",
            "-f", "rawvideo", "-s", (char *)wh, "-pix_fmt", "bgra", "-r", "30", "-i", fifo1,
            "-vf", "vflip", "-pix_fmt", "yuv420p", "-c:v", "mpeg4", out1 };
        zenith_ffmpeg_make_fifo(fifo1);
        int ok = zenith_ffmpeg_start((int)(sizeof a / sizeof *a), a) == 0;
        int fd = ok ? zenith_ffmpeg_open_fifo_writer(fifo1, 10000) : -1;
        unsigned char *frame = malloc(W * H * 4);
        for (int f = 0; f < 20 && fd >= 0; f++) { make_frame(frame, f); zenith_ffmpeg_write_fully(fd, frame, W * H * 4); }
        zenith_ffmpeg_cancel();
        /* keep the pipe open a moment like a render loop that hasn't noticed yet */
        for (int f = 20; f < 25 && fd >= 0; f++) { make_frame(frame, f); if (zenith_ffmpeg_write_fully(fd, frame, W * H * 4)) break; }
        zenith_ffmpeg_close_fd(fd);
        free(frame);
        int ret = zenith_ffmpeg_wait();
        unlink(fifo1);
        drain_log(log, sizeof log);
        CHECK(ok && fd >= 0, "started and opened fifo");
        CHECK(!zenith_ffmpeg_is_running(), "no longer running after wait (ret %d)", ret);
        CHECK(file_size(out1) > 100, "output file written (%d bytes)", file_size(out1));
    }

    printf("\n%s (%d failure%s)\n", failures ? "FAILED" : "ALL PASSED", failures, failures == 1 ? "" : "s");
    return failures != 0;
}
