using System;
using System.IO;
using System.Text.Json;
using System.Text.Json.Serialization;
using ZenithEngine;

namespace Zenith.iOS
{
    /// <summary>Everything the app remembers between launches.</summary>
    public class AppSettings
    {
        public MidiTrailSettings Trail = new MidiTrailSettings();

        // export screen
        public int ResolutionIndex = 1;     // 0=720p 1=1080p 2=1440p 3=4K
        public int SsaaIndex = 0;           // 0=off 1=2x
        public int FpsIndex = 1;            // 0=30 1=60
        public int BitrateMbps = 20;
        public bool UseBitrate = true;
        public int Quality = 17;            // desktop-style "CRF" 0..51 (lower = better)
        public bool Hevc = false;
        public bool Mask = false;
    }

    [JsonSourceGenerationOptions(IncludeFields = true, WriteIndented = true)]
    [JsonSerializable(typeof(AppSettings))]
    internal partial class AppJsonContext : JsonSerializerContext { }

    internal static class SettingsStore
    {
        static string FilePath => Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "zenith-settings.json");

        static AppSettings current;
        public static AppSettings Current => current ??= Load();

        static AppSettings Load()
        {
            try
            {
                if (File.Exists(FilePath))
                {
                    var s = JsonSerializer.Deserialize(File.ReadAllText(FilePath), AppJsonContext.Default.AppSettings);
                    if (s != null) { s.Trail ??= new MidiTrailSettings(); return s; }
                }
            }
            catch (Exception e) { Console.WriteLine("Settings load failed: " + e.Message); }
            return new AppSettings();
        }

        public static void Save()
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(FilePath));
                File.WriteAllText(FilePath, JsonSerializer.Serialize(Current, AppJsonContext.Default.AppSettings));
            }
            catch (Exception e) { Console.WriteLine("Settings save failed: " + e.Message); }
        }
    }
}
