using System;

namespace ZenithEngine
{
    /// <summary>
    /// Engine-wide settings (resolution, fps, export options).  Field names match the
    /// desktop RenderSettings so the engine files copied from Zenith work unchanged.
    /// </summary>
    public class RenderSettings
    {
        public int fps = 60;

        public int width = 1920;
        public int height = 1080;
        public int downscale = 1;           // SSAA factor: render at width*height, output width/downscale

        public bool ffRender = false;
        public string ffPath = "";
        public bool ffRenderMask = false;   // also write an alpha-mask video
        public string ffMaskPath = "";
        public double renderSecondsDelay = 0;

        private bool paused = false;
        public bool forceReRender = true;
        public double tempoMultiplier = 1;

        public bool includeAudio = false;
        public string audioPath = "";

        public int maxTrackBufferSize = 10000;

        public bool useBitrate = true;
        public int bitrate = 20000;         // kbit/s
        public int crf = 17;                // used to derive a quality when useBitrate is false
        public bool hevc = false;           // HEVC instead of H.264

        public volatile bool running = false;

        public bool playbackEnabled = true; // read by the MIDI parser
        public bool realtimePlayback = true;
        public double liveFps = 0;
        public bool timeBasedNotes = false;
        public bool ignoreColorEvents = false;

        public event Action PauseToggled;
        public bool Paused
        {
            get => paused;
            set
            {
                paused = value;
                PauseToggled?.Invoke();
            }
        }
    }
}
