using System;

namespace ZenithEngine
{
    /// <summary>
    /// 4x4 matrix with exactly OpenTK's conventions: row vectors, "a * b" applies a
    /// first, translation in the bottom row.  <see cref="M"/> is row-major, and
    /// uploading it unchanged with glUniformMatrix4fv(transpose = false) makes a
    /// GLSL "MVP * vec4(position, 1)" behave the same as OpenTK's code did.
    /// </summary>
    public sealed class Matrix4
    {
        public readonly float[] M = new float[16];

        public Matrix4() { M[0] = M[5] = M[10] = M[15] = 1f; }

        public static Matrix4 Identity => new Matrix4();

        public static Matrix4 CreateTranslation(float x, float y, float z)
        {
            var r = new Matrix4();
            r.M[12] = x; r.M[13] = y; r.M[14] = z;
            return r;
        }

        public static Matrix4 CreateScale(float x, float y, float z)
        {
            var r = new Matrix4();
            r.M[0] = x; r.M[5] = y; r.M[10] = z;
            return r;
        }

        public static Matrix4 CreateRotationX(float angle)
        {
            float c = (float)Math.Cos(angle), s = (float)Math.Sin(angle);
            var r = new Matrix4();
            r.M[5] = c;  r.M[6] = s;
            r.M[9] = -s; r.M[10] = c;
            return r;
        }

        public static Matrix4 CreateRotationY(float angle)
        {
            float c = (float)Math.Cos(angle), s = (float)Math.Sin(angle);
            var r = new Matrix4();
            r.M[0] = c;  r.M[2] = -s;
            r.M[8] = s;  r.M[10] = c;
            return r;
        }

        public static Matrix4 CreateRotationZ(float angle)
        {
            float c = (float)Math.Cos(angle), s = (float)Math.Sin(angle);
            var r = new Matrix4();
            r.M[0] = c;  r.M[1] = s;
            r.M[4] = -s; r.M[5] = c;
            return r;
        }

        public static Matrix4 CreatePerspectiveFieldOfView(float fovy, float aspect, float zNear, float zFar)
        {
            float maxY = zNear * (float)Math.Tan(0.5 * fovy);
            float minY = -maxY;
            float minX = minY * aspect;
            float maxX = maxY * aspect;

            float x = (2f * zNear) / (maxX - minX);
            float y = (2f * zNear) / (maxY - minY);
            float a = (maxX + minX) / (maxX - minX);
            float b = (maxY + minY) / (maxY - minY);
            float c = -(zFar + zNear) / (zFar - zNear);
            float d = -(2f * zFar * zNear) / (zFar - zNear);

            var r = new Matrix4();
            r.M[0] = x;  r.M[1] = 0;  r.M[2] = 0;   r.M[3] = 0;
            r.M[4] = 0;  r.M[5] = y;  r.M[6] = 0;   r.M[7] = 0;
            r.M[8] = a;  r.M[9] = b;  r.M[10] = c;  r.M[11] = -1;
            r.M[12] = 0; r.M[13] = 0; r.M[14] = d;  r.M[15] = 0;
            return r;
        }

        public static Matrix4 operator *(Matrix4 left, Matrix4 right)
        {
            var r = new Matrix4();
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    float sum = 0f;
                    for (int k = 0; k < 4; k++)
                        sum += left.M[i * 4 + k] * right.M[k * 4 + j];
                    r.M[i * 4 + j] = sum;
                }
            }
            return r;
        }
    }
}
