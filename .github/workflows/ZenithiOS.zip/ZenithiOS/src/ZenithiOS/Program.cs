using UIKit;

namespace Zenith.iOS
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            UIApplication.Main(args, null, typeof(AppDelegate));
        }
    }
}
