#!/usr/bin/env bash
#
# Build ffmpeg for iOS and package it as ZenithFFmpeg.xcframework.
#
# Needs a Mac with Xcode (or the Command Line Tools + an iOS SDK) and git.
#
#   ./build-ffmpeg-ios.sh                 # device (arm64) + simulator (arm64)
#   SLICES="device" ./build-ffmpeg-ios.sh # device only (faster)
#
# What you get in ./out :
#   ZenithFFmpeg.xcframework      <- reference this from the app
#   ios-arm64/libZenithFFmpeg.a   <- the same library as a plain .a, per slice
#   ios-arm64-simulator/libZenithFFmpeg.a
#   include/zenith_ffmpeg.h
#
# LICENSING: by default this builds an LGPL-2.1+ ffmpeg (no GPL parts, no
# libx264).  H.264/HEVC encoding uses Apple's hardware encoders through
# VideoToolbox.  Set ENABLE_X264=1 only if you have built libx264 for iOS
# yourself (see X264_PREFIX_* below) - the result is GPL and cannot be
# shipped through the App Store.
#
set -euo pipefail

FFMPEG_TAG="${FFMPEG_TAG:-n7.1.1}"
IOS_MIN="${IOS_MIN:-15.0}"
SLICES="${SLICES:-device simulator}"
JOBS="${JOBS:-$(sysctl -n hw.ncpu)}"

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(cd "$HERE/.." && pwd)"
WORK="${WORK:-$ROOT/build-ios}"
OUT="${OUT:-$ROOT/out}"
SRC="$WORK/ffmpeg-src"

[ "$(uname)" = "Darwin" ] || { echo "This script must run on macOS (it needs the iOS SDK)."; exit 1; }
command -v xcrun >/dev/null || { echo "xcrun not found: install Xcode or the Command Line Tools."; exit 1; }

# ---- source ------------------------------------------------------------------
mkdir -p "$WORK" "$OUT"
if [ ! -d "$SRC" ]; then
  git clone --depth 1 --branch "$FFMPEG_TAG" https://github.com/FFmpeg/FFmpeg.git "$SRC"
  git -C "$SRC" apply "$ROOT/patches/0001-zenith-library-entry.patch"
fi

# fftools objects that make up the ffmpeg command line tool (main() is renamed
# to zenith_ffmpeg_main by the patch, so they link into an app).
CLI_OBJS="fftools/ffmpeg.o fftools/ffmpeg_dec.o fftools/ffmpeg_demux.o fftools/ffmpeg_enc.o
 fftools/ffmpeg_filter.o fftools/ffmpeg_hw.o fftools/ffmpeg_mux.o fftools/ffmpeg_mux_init.o
 fftools/ffmpeg_opt.o fftools/ffmpeg_sched.o fftools/objpool.o fftools/sync_queue.o
 fftools/thread_queue.o fftools/cmdutils.o fftools/opt_common.o"
LIBS="libavfilter/libavfilter.a libavformat/libavformat.a libavcodec/libavcodec.a
 libswscale/libswscale.a libswresample/libswresample.a libavutil/libavutil.a"

# ---- what goes into the build --------------------------------------------------
# Encoders: hardware H.264/HEVC/ProRes, AAC, plus lossless/intermediate formats.
ENCODERS="h264_videotoolbox,hevc_videotoolbox,prores_videotoolbox,aac,aac_at,pcm_s16le,pcm_s24le,alac,flac,png,mjpeg,rawvideo"
MUXERS="mp4,mov,matroska,webm,wav,flac,ipod,image2,null"

COMMON_CONFIG=(
  --enable-cross-compile --target-os=darwin --arch=arm64
  --enable-static --disable-shared --enable-pic
  --disable-debug --disable-doc --disable-ffplay --disable-ffprobe
  --disable-avdevice --disable-network --disable-autodetect
  --enable-videotoolbox --enable-audiotoolbox
  --enable-zlib --enable-bzlib --enable-iconv
  --disable-encoders "--enable-encoder=$ENCODERS"
  --disable-muxers   "--enable-muxer=$MUXERS"
  --enable-lto
)
if [ "${ENABLE_X264:-0}" = "1" ]; then
  echo "WARNING: building with libx264 => GPL licensed ffmpeg."
fi

build_slice() {
  local name="$1" sdk="$2" target_flags="$3" x264_prefix="${4:-}"
  local B="$WORK/$name"
  local CC_CMD="xcrun --sdk $sdk clang"
  local CFLAGS="$target_flags -fno-common"
  local LDFLAGS="$target_flags"
  local EXTRA=()

  if [ "${ENABLE_X264:-0}" = "1" ]; then
    [ -n "$x264_prefix" ] && [ -d "$x264_prefix" ] || { echo "Set X264_PREFIX_${name^^} to an iOS build of libx264."; exit 1; }
    EXTRA+=(--enable-gpl --enable-libx264 "--enable-encoder=libx264")
    CFLAGS="$CFLAGS -I$x264_prefix/include"
    LDFLAGS="$LDFLAGS -L$x264_prefix/lib"
    export PKG_CONFIG_PATH="$x264_prefix/lib/pkgconfig"
  fi

  echo "=== ffmpeg slice: $name ($sdk) ==="
  rm -rf "$B"; mkdir -p "$B"; cd "$B"
  "$SRC/configure" "${COMMON_CONFIG[@]}" "${EXTRA[@]}" \
    --cc="$CC_CMD" --ld="$CC_CMD" \
    --extra-cflags="$CFLAGS" --extra-ldflags="$LDFLAGS"

  # shellcheck disable=SC2086
  make -j"$JOBS" $LIBS $CLI_OBJS

  # the in-process wrapper (FIFO helpers, log capture, run/cancel)
  $CC_CMD $CFLAGS -O2 -I"$ROOT/src" -I"$B" -I"$SRC" -c "$ROOT/src/zenith_ffmpeg.c" -o zenith_ffmpeg.o

  mkdir -p "$OUT/$name"
  # shellcheck disable=SC2086
  libtool -static -o "$OUT/$name/libZenithFFmpeg.a" $LIBS $CLI_OBJS zenith_ffmpeg.o
  echo "-> $OUT/$name/libZenithFFmpeg.a"
}

XC_ARGS=()
mkdir -p "$OUT/include" && cp "$ROOT/src/zenith_ffmpeg.h" "$OUT/include/"

for s in $SLICES; do
  case "$s" in
    device)
      build_slice ios-arm64 iphoneos "-arch arm64 -miphoneos-version-min=$IOS_MIN" "${X264_PREFIX_IOS_ARM64:-}"
      XC_ARGS+=(-library "$OUT/ios-arm64/libZenithFFmpeg.a" -headers "$OUT/include")
      ;;
    simulator)
      build_slice ios-arm64-simulator iphonesimulator "-arch arm64 -target arm64-apple-ios${IOS_MIN}-simulator" "${X264_PREFIX_IOS_ARM64_SIMULATOR:-}"
      XC_ARGS+=(-library "$OUT/ios-arm64-simulator/libZenithFFmpeg.a" -headers "$OUT/include")
      ;;
    *) echo "unknown slice '$s' (use: device simulator)"; exit 1 ;;
  esac
done

rm -rf "$OUT/ZenithFFmpeg.xcframework"
xcodebuild -create-xcframework "${XC_ARGS[@]}" -output "$OUT/ZenithFFmpeg.xcframework"

echo
echo "Done: $OUT/ZenithFFmpeg.xcframework"
echo "Next: build the app (see ../README.md)."
