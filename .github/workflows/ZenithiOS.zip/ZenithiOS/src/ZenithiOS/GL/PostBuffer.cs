using System;

namespace Zenith.iOS.GL
{
    /// <summary>Colour-only framebuffer with a texture (port of GLPostbuffer / GLUtils.GenFrameBufferTexture).</summary>
    internal sealed class PostBuffer : IDisposable
    {
        public int BufferID { get; private set; }
        public int TextureID { get; private set; }
        public int Width { get; }
        public int Height { get; }

        public PostBuffer(int width, int height)
        {
            Width = width;
            Height = height;
            BufferID = Gl.GenFramebuffer();
            Gl.glBindFramebuffer(Gl.FRAMEBUFFER, BufferID);
            TextureID = Gl.GenTexture();
            Gl.glBindTexture(Gl.TEXTURE_2D, TextureID);
            Gl.TexImage2DRgba(width, height, null);
            Gl.glTexParameteri(Gl.TEXTURE_2D, Gl.TEXTURE_MIN_FILTER, Gl.LINEAR);
            Gl.glTexParameteri(Gl.TEXTURE_2D, Gl.TEXTURE_MAG_FILTER, Gl.LINEAR);
            Gl.glFramebufferTexture2D(Gl.FRAMEBUFFER, Gl.COLOR_ATTACHMENT0, Gl.TEXTURE_2D, TextureID, 0);
            if (Gl.glCheckFramebufferStatus(Gl.FRAMEBUFFER) != Gl.FRAMEBUFFER_COMPLETE)
                throw new InvalidOperationException("Framebuffer incomplete (" + width + "x" + height + ") - the resolution may be too large for this device");
        }

        public void BindBuffer() { Gl.glBindFramebuffer(Gl.FRAMEBUFFER, BufferID); }
        public void BindTexture() { Gl.glBindTexture(Gl.TEXTURE_2D, TextureID); }

        public void Dispose()
        {
            if (BufferID != 0) Gl.DeleteFramebuffer(BufferID);
            if (TextureID != 0) Gl.DeleteTexture(TextureID);
            BufferID = 0;
            TextureID = 0;
        }
    }

    /// <summary>Colour + depth framebuffer (port of GLUtils.GenFrameBufferTexture3d), used by MIDITrail+.</summary>
    internal sealed class PostBuffer3D : IDisposable
    {
        public int BufferID { get; private set; }
        public int TextureID { get; private set; }
        public int DepthID { get; private set; }

        public PostBuffer3D(int width, int height)
        {
            BufferID = Gl.GenFramebuffer();
            Gl.glBindFramebuffer(Gl.FRAMEBUFFER, BufferID);
            TextureID = Gl.GenTexture();
            Gl.glBindTexture(Gl.TEXTURE_2D, TextureID);
            Gl.TexImage2DRgba(width, height, null);
            Gl.glTexParameteri(Gl.TEXTURE_2D, Gl.TEXTURE_MIN_FILTER, Gl.LINEAR);
            Gl.glTexParameteri(Gl.TEXTURE_2D, Gl.TEXTURE_MAG_FILTER, Gl.LINEAR);

            DepthID = Gl.GenRenderbuffer();
            Gl.glBindRenderbuffer(Gl.RENDERBUFFER, DepthID);
            Gl.glRenderbufferStorage(Gl.RENDERBUFFER, Gl.DEPTH_COMPONENT24, width, height);
            Gl.glFramebufferRenderbuffer(Gl.FRAMEBUFFER, Gl.DEPTH_ATTACHMENT, Gl.RENDERBUFFER, DepthID);

            Gl.glFramebufferTexture2D(Gl.FRAMEBUFFER, Gl.COLOR_ATTACHMENT0, Gl.TEXTURE_2D, TextureID, 0);
            if (Gl.glCheckFramebufferStatus(Gl.FRAMEBUFFER) != Gl.FRAMEBUFFER_COMPLETE)
                throw new InvalidOperationException("3D framebuffer incomplete (" + width + "x" + height + ") - the resolution may be too large for this device");
        }

        public void BindBuffer() { Gl.glBindFramebuffer(Gl.FRAMEBUFFER, BufferID); }
        public void BindTexture() { Gl.glBindTexture(Gl.TEXTURE_2D, TextureID); }

        public void Dispose()
        {
            if (BufferID != 0) Gl.DeleteFramebuffer(BufferID);
            if (TextureID != 0) Gl.DeleteTexture(TextureID);
            if (DepthID != 0) Gl.DeleteRenderbuffer(DepthID);
            BufferID = TextureID = DepthID = 0;
        }
    }
}
