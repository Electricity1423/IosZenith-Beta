using System;
using CoreAnimation;
using CoreGraphics;
using Foundation;
using GLKit;
using OpenGLES;
using UIKit;
using Zenith.iOS.Render;
using ZenithEngine;

namespace Zenith.iOS.UI
{
    /// <summary>GL view that runs a RenderSession in real time.</summary>
    internal sealed class PreviewView : GLKView
    {
        public RenderSession Session;
        public RenderSettings Settings;
        public Action<string> OnError;
        public Action OnFinished;
        bool failed;

        public PreviewView(CGRect frame, EAGLContext ctx) : base(frame, ctx)
        {
            DrawableColorFormat = GLKViewDrawableColorFormat.RGBA8888;
            DrawableDepthFormat = GLKViewDrawableDepthFormat.None;
            EnableSetNeedsDisplay = false;
            ContentScaleFactor = UIScreen.MainScreen.Scale;
        }

        public override void Draw(CGRect rect)
        {
            if (Session == null || failed) return;
            try
            {
                EAGLContext.SetCurrentContext(Context);
                if (!Session.Step(true)) { OnFinished?.Invoke(); return; }
                BindDrawable();
                Session.Present((int)DrawableWidth, (int)DrawableHeight);
                if (Session.Error != null) throw Session.Error;
            }
            catch (Exception ex)
            {
                failed = true;
                OnError?.Invoke(ex.Message);
            }
        }
    }

    internal sealed class PreviewViewController : UIViewController
    {
        EAGLContext ctx;
        PreviewView view;
        RenderSession session;
        CADisplayLink link;
        UIButton pauseBtn;
        UILabel status;
        UIProgressView progress;
        NSObject obsResign, obsActive;
        bool finished;

        public PreviewViewController() { Title = "Preview"; }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();
            View.BackgroundColor = UIColor.Black;

            ctx = new EAGLContext(EAGLRenderingAPI.OpenGLES3);
            view = new PreviewView(CGRect.Empty, ctx) { TranslatesAutoresizingMaskIntoConstraints = false };
            view.OnError = msg => InvokeOnMainThread(() => { status.Text = "Error: " + msg; Stop(); });
            view.OnFinished = () => InvokeOnMainThread(() => { finished = true; status.Text = "Finished"; pauseBtn.SetTitle("Restart", UIControlState.Normal); link.Paused = true; });
            View.AddSubview(view);

            progress = new UIProgressView(UIProgressViewStyle.Default) { TranslatesAutoresizingMaskIntoConstraints = false };
            status = new UILabel { TextColor = UIColor.White, Font = UIFont.MonospacedDigitSystemFontOfSize(13, UIFontWeight.Regular), TranslatesAutoresizingMaskIntoConstraints = false, Lines = 2 };
            pauseBtn = Btn("Pause", TogglePause);
            var fwd = Btn("+5s", () => session?.SkipForward(5000));
            var row = new UIStackView(new UIView[] { pauseBtn, fwd }) { Axis = UILayoutConstraintAxis.Horizontal, Spacing = 12, Distribution = UIStackViewDistribution.FillEqually, TranslatesAutoresizingMaskIntoConstraints = false };
            View.AddSubview(progress); View.AddSubview(status); View.AddSubview(row);

            NSLayoutConstraint.ActivateConstraints(new[]
            {
                view.TopAnchor.ConstraintEqualTo(View.SafeAreaLayoutGuide.TopAnchor),
                view.LeadingAnchor.ConstraintEqualTo(View.LeadingAnchor),
                view.TrailingAnchor.ConstraintEqualTo(View.TrailingAnchor),
                view.BottomAnchor.ConstraintEqualTo(progress.TopAnchor, -8),
                progress.LeadingAnchor.ConstraintEqualTo(View.LeadingAnchor, 16),
                progress.TrailingAnchor.ConstraintEqualTo(View.TrailingAnchor, -16),
                progress.BottomAnchor.ConstraintEqualTo(status.TopAnchor, -6),
                status.LeadingAnchor.ConstraintEqualTo(View.LeadingAnchor, 16),
                status.TrailingAnchor.ConstraintEqualTo(View.TrailingAnchor, -16),
                status.BottomAnchor.ConstraintEqualTo(row.TopAnchor, -10),
                row.LeadingAnchor.ConstraintEqualTo(View.LeadingAnchor, 16),
                row.TrailingAnchor.ConstraintEqualTo(View.TrailingAnchor, -16),
                row.BottomAnchor.ConstraintEqualTo(View.SafeAreaLayoutGuide.BottomAnchor, -10),
                row.HeightAnchor.ConstraintEqualTo(44),
            });
        }

        UIButton Btn(string t, Action a)
        {
            var b = UIButton.FromType(UIButtonType.System);
            b.SetTitle(t, UIControlState.Normal);
            b.BackgroundColor = UIColor.FromWhiteAlpha(0.2f, 1);
            b.Layer.CornerRadius = 8;
            b.TouchUpInside += (s, e) => a();
            return b;
        }

        public override void ViewDidAppear(bool animated)
        {
            base.ViewDidAppear(animated);
            if (session == null) StartSession();
            obsResign = UIApplication.Notifications.ObserveWillResignActive((s, e) => { if (link != null) link.Paused = true; });
            obsActive = UIApplication.Notifications.ObserveDidBecomeActive((s, e) => { if (link != null && session != null && !finished) link.Paused = false; });
            UIApplication.SharedApplication.IdleTimerDisabled = true;
        }

        void StartSession()
        {
            var midi = AppState.Midi;
            if (midi == null) { status.Text = "No MIDI loaded"; return; }
            try
            {
                EAGLContext.SetCurrentContext(ctx);
                var rs = new RenderSettings { fps = 60, width = 1280, height = 720, realtimePlayback = true, ffRender = false };
                session = new RenderSession(midi, rs, SettingsStore.Current.Trail.Clone(), AppState.Aura, false);
                view.Settings = rs;
                view.Session = session;
                link = CADisplayLink.Create(Tick);
                link.PreferredFramesPerSecond = 60;
                link.AddToRunLoop(NSRunLoop.Main, NSRunLoopMode.Default);
            }
            catch (Exception ex) { status.Text = "Couldn't start preview: " + ex.Message; }
        }

        int tickCount;
        void Tick()
        {
            view.Display();
            if ((++tickCount & 7) == 0 && session != null)
            {
                progress.Progress = (float)Math.Max(0, Math.Min(1, session.Progress));
                status.Text = $"{session.NotesOnScreen:N0} notes on screen · {session.Progress * 100:0.0}%" + (view.Settings.Paused ? " · paused" : "");
            }
        }

        void TogglePause()
        {
            if (session == null) return;
            if (finished)
            {
                // restart: rebuild the session
                Stop(false);
                finished = false;
                pauseBtn.SetTitle("Pause", UIControlState.Normal);
                StartSession();
                return;
            }
            view.Settings.Paused = !view.Settings.Paused;
            pauseBtn.SetTitle(view.Settings.Paused ? "Resume" : "Pause", UIControlState.Normal);
        }

        void Stop(bool full = true)
        {
            if (link != null) { link.Invalidate(); link = null; }
            if (view != null) view.Session = null;
            if (session != null)
            {
                EAGLContext.SetCurrentContext(ctx);
                try { session.Settings.running = false; session.Dispose(); } catch (Exception e) { Console.WriteLine(e); }
                session = null;
            }
        }

        public override void ViewWillDisappear(bool animated)
        {
            base.ViewWillDisappear(animated);
            if (IsMovingFromParentViewController || IsBeingDismissed)
            {
                Stop();
                obsResign?.Dispose(); obsActive?.Dispose();
                UIApplication.SharedApplication.IdleTimerDisabled = false;
                EAGLContext.SetCurrentContext(null);
            }
        }
    }
}
